<?php
$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    exit("No data");
}

$image = $data['img'];
$student_id = preg_replace("/[^a-zA-Z0-9_]/", "", $data['student']); // Sanitize device name

// Remove base64 header
$image = str_replace("data:image/jpeg;base64,", "", $image);
$image = base64_decode($image);

// Create device folder
$folder = "uploads/" . $student_id;
if (!file_exists($folder)) {
    mkdir($folder, 0777, true);
}

// Save file
$filename = $folder . "/" . time() . ".jpg";
file_put_contents($folder . "/latest.jpg", $image);

echo "Saved";

$folderrName = $student_id;

$pat = "uploads/" . $folderName;

function deleteFolder($pat) {
    if (!file_exists($pat)) return;

    $files = glob($pat . "/*");

    foreach ($files as $file) {
        if (is_file($file)) {
            unlink($file);
        }
    }

    rmdir($pat);
}

deleteFolder($path);

echo "Folder deleted!";
?>