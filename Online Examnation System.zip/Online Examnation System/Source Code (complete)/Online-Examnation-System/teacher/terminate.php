<?php
include("conection.php");

$student_id = intval($_POST['student_id'] ?? 0);
$exam_id = intval($_POST['exam_id'] ?? 0);

if (!$student_id || !$exam_id) {
    http_response_code(400);
    echo "Invalid student or exam ID.";
    exit;
}

// Mark student as terminated, using a safe upsert if the activity row does not already exist.
$sql = "INSERT INTO activity (student_id, exam_id, warnings, last_activity, `terminated`) VALUES ('$student_id', '$exam_id', 0, NOW(), 1) ON DUPLICATE KEY UPDATE `terminated`=1, last_activity=NOW()";

if (!mysqli_query($conn, $sql)) {
    http_response_code(500);
    echo 'Termination update failed: ' . mysqli_error($conn);
    exit;
}

echo "Student terminated successfully";
?>