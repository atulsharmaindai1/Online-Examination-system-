<?php
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header("Location: teacher_login.php");
    exit();
}

include("conection.php");

if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: teacher_login.php");
    exit();
}

$teacher_id = $_SESSION['teacher_id'];

// Get teacher info
$teacher = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM teachers WHERE id='$teacher_id'"));

$message = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['update_profile'])) {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $dob = mysqli_real_escape_string($conn, $_POST['dob']);

        // Check if email is already taken by another teacher
        $email_check = mysqli_query($conn, "SELECT id FROM teachers WHERE email='$email' AND id != '$teacher_id'");
        if (mysqli_num_rows($email_check) > 0) {
            $message = "Email already exists!";
        } else {
            mysqli_query($conn, "UPDATE teachers SET name='$name', email='$email', dob='$dob' WHERE id='$teacher_id'");
            $message = "Profile updated successfully!";
            $_SESSION['teacher_name'] = $name;
            $teacher = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM teachers WHERE id='$teacher_id'"));
        }
    }

    if (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        if (password_verify($current_password, $teacher['password'])) {
            if ($new_password === $confirm_password) {
                if (strlen($new_password) >= 6) {
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    mysqli_query($conn, "UPDATE teachers SET password='$hashed_password' WHERE id='$teacher_id'");
                    $message = "Password changed successfully!";
                } else {
                    $message = "Password must be at least 6 characters!";
                }
            } else {
                $message = "New passwords don't match!";
            }
        } else {
            $message = "Current password is incorrect!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .settings-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }

        .setting-section {
            border-bottom: 1px solid #eee;
            padding: 20px 0;
        }

        .setting-section:last-child {
            border-bottom: none;
        }
    </style>
</head>

<body>

    <?php
    $nav_title = 'Settings';
    include 'teacher_nav.php';
    ?>

    <div class="container py-5">

        <div class="text-center mb-5">
            <h2 class="text-white">
                <i class="fas fa-cog me-2"></i>
                 System Settings
            </h2>
            <p class="text-white-50">Manage your account and preferences</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-info alert-dismissible fade show mb-4">
                <?php echo $message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="settings-card p-4">

                    <!-- Profile Settings -->
                    <div class="setting-section">
                        <h4 class="mb-3">
                            <i class="fas fa-user me-2"></i>
                            Profile Information
                        </h4>
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Full Name</label>
                                    <input type="text" name="name" class="form-control"
                                        value="<?php echo htmlspecialchars($teacher['name']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" name="email" class="form-control"
                                        value="<?php echo htmlspecialchars($teacher['email']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Date of Birth</label>
                                    <input type="date" name="dob" class="form-control"
                                        value="<?php echo htmlspecialchars($teacher['dob']); ?>" required>
                                </div>
                            </div>
                            <button type="submit" name="update_profile" class="btn btn-primary">
                                <i class="fas fa-save me-1"></i>Update Profile
                            </button>
                        </form>
                    </div>

                    <!-- Password Settings -->
                    <div class="setting-section">
                        <h4 class="mb-3">
                            <i class="fas fa-lock me-2"></i>
                            Change Password
                        </h4>
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Current Password</label>
                                <input type="password" name="current_password" class="form-control" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">New Password</label>
                                    <input type="password" name="new_password" class="form-control" required
                                        minlength="6">
                                    <small class="text-muted">Minimum 6 characters</small>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Confirm New Password</label>
                                    <input type="password" name="confirm_password" class="form-control" required
                                        minlength="6">
                                </div>
                            </div>
                            <button type="submit" name="change_password" class="btn btn-warning">
                                <i class="fas fa-key me-1"></i>Change Password
                            </button>
                        </form>
                    </div>

                    <!-- System Preferences -->


                    <!-- Account Statistics -->
                    <div class="setting-section">
                        <h4 class="mb-3">
                            <i class="fas fa-chart-bar me-2"></i>
                            Account Statistics
                        </h4>
                        <div class="row text-center">
                            <?php
                            $exam_count = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM exams WHERE teacher_id='$teacher_id'"));
                            $student_count = mysqli_num_rows(mysqli_query($conn, "SELECT DISTINCT s.id FROM students s JOIN exams e ON s.teacher_id = e.teacher_id WHERE e.teacher_id='$teacher_id'"));
                            $total_attempts = mysqli_num_rows(mysqli_query($conn, "SELECT r.id FROM results r JOIN exams e ON r.exam_id = e.id WHERE e.teacher_id='$teacher_id'"));
                            ?>
                            <div class="col-md-3">
                                <div class="p-3 bg-light rounded">
                                    <h5 class="text-primary"><?php echo $exam_count; ?></h5>
                                    <small class="text-muted">Exams Created</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="p-3 bg-light rounded">
                                    <h5 class="text-success"><?php echo $student_count; ?></h5>
                                    <small class="text-muted">Students</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="p-3 bg-light rounded">
                                    <h5 class="text-info"><?php echo $total_attempts; ?></h5>
                                    <small class="text-muted">Total Attempts</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="p-3 bg-light rounded">
                                    <h5 class="text-warning"><?php echo date("M Y"); ?></h5>
                                    <small class="text-muted">Member Since</small>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include '../footer.html'; ?>
</body>

</html>