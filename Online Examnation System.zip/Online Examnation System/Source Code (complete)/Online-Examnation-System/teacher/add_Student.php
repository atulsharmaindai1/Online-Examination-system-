<?php
session_start();

//  Protect page (only teacher can access)
if (!isset($_SESSION['teacher_id'])) {
    header("Location: teacher_login.php");
    exit();
}
include("conection.php");

if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: teacher_login.php");
    exit();
}

$message = "";

// ✅ Run on submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // 🔍 Check email exists
    $check = "SELECT * FROM students WHERE email='$email'";
    $result = mysqli_query($conn, $check);

    if (mysqli_num_rows($result) > 0) {
        $message = " Email already exists!";
    } else {

        $teacher_id = $_SESSION['teacher_id'];

        $sql = "INSERT INTO students (name, email, mobile, password, teacher_id)
        VALUES ('$name', '$email', '$mobile', '$password', '$teacher_id')";
        
        if (mysqli_query($conn, $sql)) {
            $message = "✅ Student Added Successfully!";
        } else {
            $message = "Error!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Add Student</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .footer{
          margin-top:50px;
        }
    </style>
</head>

<body class="bg-light">

    <?php
    $nav_title = 'Add Student';
    include 'teacher_nav.php';
    ?>

    <div class="container mt-5">

        <div class="card col-md-6 mx-auto shadow p-4">

            <h3 class="text-center mb-3"> Add Student</h3>

            <!-- Message -->
            <?php if (!empty($message)) { ?>
                <div class="alert alert-info text-center">
                    <?php echo $message; ?>
                </div>
            <?php } ?>

            <form method="POST">

                <div class="mb-3">
                    <input type="text" name="name" class="form-control" placeholder="Full Name" required>
                </div>

                <div class="mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Email" required>
                </div>

                <div class="mb-3">
                    <input type="text" name="mobile" class="form-control" placeholder="Mobile">
                </div>

                <div class="mb-3">
                    <input type="password" name="password" class="form-control" placeholder="Password" required>
                </div>

                <button type="submit" class="btn btn-primary w-100">
                    Add Student
                </button>

            </form>

            <a href="teacher_dashboard.php" class="btn btn-secondary mt-3 w-100">
                ⬅ Back to Dashboard
            </a>

        </div>

    </div>

    <?php include '../footer.html'; ?>
</body>

</html>