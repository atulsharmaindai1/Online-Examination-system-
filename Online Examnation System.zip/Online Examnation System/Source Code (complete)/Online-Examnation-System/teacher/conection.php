<?php 
$conn = mysqli_connect("localhost", "root", "", "Online_Exam");
?>