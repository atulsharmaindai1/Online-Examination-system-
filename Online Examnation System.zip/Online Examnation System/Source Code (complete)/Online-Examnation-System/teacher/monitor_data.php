<?php
session_start();
if (!isset($_SESSION['teacher_id'])) {
    header("Location: teacher_login.php");
    exit();
}
include("conection.php");

$exam_id = intval($_GET['exam_id'] ?? 0);

date_default_timezone_set("Asia/Kolkata");
// Get active students in this exam
$result = mysqli_query($conn, "
    SELECT DISTINCT a.student_id, s.name, a.warnings, a.last_activity, a.`terminated`
    FROM activity a
    JOIN students s ON a.student_id = s.id
    WHERE a.exam_id='$exam_id'
    ORDER BY a.last_activity DESC
");

if (!$result) {
    error_log('monitor_data query failed: ' . mysqli_error($conn));
    echo "<tr><td colspan='4' class='text-center'>No active student data available.</td></tr>";
    exit;
}

if (mysqli_num_rows($result) === 0) {
    echo "<tr><td colspan='4' class='text-center'>No student activity found for this exam.</td></tr>";
    exit;
}

while($row = mysqli_fetch_assoc($result)){
    $status = "Active";
    $status_class = "success";

    if($row['terminated'] == 1){
        $status = "Terminated";
        $status_class = "danger";
    } else {
        // Check if inactive for more than 2 minutes
        $last_time = strtotime($row['last_activity']);
        $now = time();
        $deff = $now - $last_time;
        
        if( $deff > 10 ){
            $status = "Inactive";
            $status_class = "warning";
        }
    }

    $action = $row['terminated'] == 1 ? "<button class='btn btn-secondary btn-sm' disabled>Terminated</button>" : "<button class='btn btn-danger btn-sm' onclick='terminate({$row['student_id']})'>Terminate</button>";

    echo "<tr>
        <td>{$row['name']}</td>
        <td><span class='badge bg-{$status_class}'>{$status}</span></td>
        <td>{$row['warnings']}</td>
        <td>{$action}</td>
    </tr>";
}
?>