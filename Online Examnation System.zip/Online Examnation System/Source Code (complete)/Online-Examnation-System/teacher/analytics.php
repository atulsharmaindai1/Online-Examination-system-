<?php
session_start();
if (!isset($_SESSION['teacher_id'])) {
    header("Location: teacher_login.php");
    exit();
}
include("conection.php");

$exam_id = $_GET['exam_id'] ?? 0;
if (!$exam_id) {
    echo "Invalid exam ID.";
    exit;
}
$teacher_id = $_SESSION['teacher_id'];
$result = mysqli_query($conn, "SELECT * FROM students WHERE teacher_id='$teacher_id'");

$student_id = glob("../camera-system/uploads/*");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Live Monitoring</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
   
        img {
            border: 1px solid #ccc;
            margin: 5px;
        }

        #footer {
            margin-top: 255px;
            width: 100%;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .grid {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: left;

        }

        .card {
            background: #252628;
            border-radius: 10px;
            padding: 15px;
            width: 260px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            transition: 0.3s;
        }

        .card:hover {
            transform: scale(1.05);
        }

        img {
            width: 100%;
            border-radius: 8px;
        }

        .name {
            font-size: 18px;
            font-weight: bold;
            margin-top: 10px;
            color: aliceblue;
        }

        .time {
            font-size: 12px;
            color: #94a3b8;
        }

        .status {
            margin-top: 5px;
            padding: 5px;
            border-radius: 5px;
            font-size: 12px;
        }

        .active {
            background: #16a34a;
        }

        .inactive {
            background: #dc2626;
        }
    </style>

</head>

<body class="bg-light">
    <?php
    $nav_title = 'live Monitoring';
    include 'teacher_nav.php';
    ?>
    <div class="container mt-4">

        <h3> Live Monitoring Dashboard</h3>

        <div class="row">

            <!--  STUDENT ACTIVITY -->
            <div class="col-md-6">
                <h5> Student Activity</h5>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Warnings</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="activityData"></tbody>
                </table>
            </div>

        </div>

        <hr>

        <h2 style="background-color: #3e3a3a; padding: 10px; color: #ccc;">Live Camera Monitoring</h2>

        <div class="grid ">

            <?php foreach ($student_id as $student): ?>
         
                <?php
                $images = glob($student . "/*.jpg");
                rsort($images);

                $latest = $images[0] ?? "";

                foreach ($images as $key => $img) {
                    if ($key != 0 && file_exists($img)) {
                        unlink($img);
                    }
                }

                
                    $name = basename($student);;
                

               
                ?>

                <?php if ($latest): ?>
                    <div class="card">
                        <img class="cam" src="<?php echo $latest; ?>?t=<?php echo time(); ?>">

                        <div class="name"><?php echo $name; ?></div>

                        <div class="time">
                            Updated: <?php echo date("H:i:s"); ?>
                        </div>

                    </div>
                <?php endif; ?>

            <?php endforeach; ?>

        </div>
        </div>
        

        <!--  Auto refresh images -->
        <script>
            setInterval(() => {
                document.querySelectorAll(".cam").forEach(img => {
                    let base = img.src.split("?")[0];
                    img.src = base + "?t=" + Date.now();
                });
            }, 3000);
            
            // ================= LOAD ACTIVITY =================
            function loadActivity() {

                fetch("monitor_data.php?exam_id=<?php echo $exam_id; ?>")
                    .then(res => res.text())
                    .then(data => {
                        document.getElementById("activityData").innerHTML = data;
                    });

            }


            // ================= TERMINATE =================
            function terminate(student_id) {

                if (confirm("Terminate this student?")) {

                    fetch("terminate.php", {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        body: "student_id=" + student_id + "&exam_id=<?php echo $exam_id; ?>"
                    })
                        .then(res => res.text())
                        .then(msg => alert(msg));

                }
            }

            // ================= AUTO REFRESH =================
            setInterval(() => {
                loadActivity();
                loadAlerts();
            }, 2000);

            // first load
            loadActivity();
            loadAlerts();

        </script>

        <?php include '../footer.html';?>
        
</body>

</html>