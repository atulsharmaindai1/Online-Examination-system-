<?php
session_start();
include("conection.php");

//  Protect page
if(!isset($_SESSION['teacher_id'])){
    header("Location: teacher_login.php");
    exit();
}

//  DELETE
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM students WHERE id='$id'");
    header("Location: view_students.php");
    exit();
}

// ✏️ UPDATE (with password)
if(isset($_POST['update'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];

    // 👉 If password not empty → update password
    if(!empty($password)){
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        $sql = "UPDATE students SET 
                name='$name', email='$email', mobile='$mobile', password='$hashed'
                WHERE id='$id'";
    } else {
        // 👉 Only update other fields
        $sql = "UPDATE students SET 
                name='$name', email='$email', mobile='$mobile'
                WHERE id='$id'";
    }

    mysqli_query($conn, $sql);
    header("Location: view_students.php");
    exit();
}

//  FETCH
$teacher_id = $_SESSION['teacher_id'];
$result = mysqli_query($conn, "SELECT * FROM students WHERE teacher_id='$teacher_id'");
?>
<!DOCTYPE html>
<html>

<head>
    <title>View Students</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
         .footer{
          margin-top:270px;
        }
    </style>
</head>

<body class="bg-light">
     <?php
    $nav_title = 'View Students';
    include 'teacher_nav.php';
    ?>

    <div class="container mt-5">

        <h2 class="mb-4"> Student List</h2>

        <table class="table table-bordered table-striped">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Password</th>
                <th>Action</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <form method="POST">
                        <td><?php echo $row['id']; ?></td>

                        <td>
                            <input type="text" name="name" value="<?php echo $row['name']; ?>" class="form-control">
                        </td>

                        <td>
                            <input type="email" name="email" value="<?php echo $row['email']; ?>" class="form-control">
                        </td>

                        <td>
                            <input type="text" name="mobile" value="<?php echo $row['mobile']; ?>" class="form-control">
                        </td>
                        <td>
                            <input type="password" name="password" placeholder="New Password" class="form-control">
                        </td>
                        <td>
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

                            <button type="submit" name="update" class="btn btn-success btn-sm">Update</button>

                            <a href="view_students.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm"
                                onclick="return confirm('Delete this student?')">
                                Delete
                            </a>
                        </td>
                    </form>
                </tr>
            <?php } ?>

        </table>

        <a href="teacher_dashboard.php" class="btn btn-secondary">⬅ Back</a>

    </div>

    <?php include '../footer.html'; ?>
</body>

</html>