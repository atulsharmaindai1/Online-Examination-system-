<?php
session_start();

//  Protect page
if (!isset($_SESSION['teacher_id'])) {
    header("Location: teacher_login.php");
    exit();
}

if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: teacher_login.php");
    exit();
}
include("conection.php");


$teacher_id = $_SESSION['teacher_id'];

//  Fetch exams of this teacher
$result = mysqli_query(
    $conn,
    "SELECT * FROM exams WHERE teacher_id='$teacher_id' ORDER BY id DESC"
);

date_default_timezone_set("Asia/Kolkata");
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Teacher Dashboard</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .dashboard-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .dashboard-card:hover {
            transform: translateY(-5px);
        }

        .stats-card {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 15px;
        }

        .exam-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>

    <?php
    $nav_title = 'Teacher Dashboard';
    $nav_extra_button = '<a href="Create_Exam.php" class="btn btn-outline-light btn-sm ms-2"><i class="fas fa-plus me-1"></i>Create Exam</a>';
    include 'teacher_nav.php';
    ?>

    <!--  Dashboard -->
    <div class="container py-5">

        <div class="text-center mb-5">
            <h2 class="text-white mb-3">
                <i class="fas fa-tachometer-alt me-2"></i>
                Teacher Dashboard
            </h2>
            <div class="mt-4">
                <a href="Create_Exam.php" class="btn btn-light btn-lg text-primary me-2">
                    <i class="fas fa-plus me-1"></i>Create Exam
                </a>
                <a href="view_students.php" class="btn btn-outline-light btn-lg">
                    <i class="fas fa-users me-1"></i>View Students
                </a>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="row mb-4">
            <?php
            $total_exams = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM exams WHERE teacher_id='$teacher_id'"));
            $total_students = mysqli_num_rows(mysqli_query($conn, "SELECT DISTINCT student_id FROM results r JOIN exams e ON r.exam_id = e.id WHERE e.teacher_id='$teacher_id'"));
            $active_exams = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM exams WHERE teacher_id='$teacher_id' AND exam_date >= CURDATE()"));
            $avg_performance = 0;
            $perf_result = mysqli_query($conn, "SELECT AVG((r.score/r.total_questions)*100) as avg_perf FROM results r JOIN exams e ON r.exam_id = e.id WHERE e.teacher_id='$teacher_id'");
            if ($perf_result) {
                if ($row = mysqli_fetch_assoc($perf_result)) {
                    $avg_performance = round($row['avg_perf'] ?? 0, 1);
                }
            } else {
                error_log('Teacher dashboard perf query failed: ' . mysqli_error($conn));
            }
            ?>
            <div class="col-md-3 mb-3">
                <div class="stats-card p-3 text-center">
                    <i class="fas fa-book fa-2x mb-2"></i>
                    <h4><?php echo $total_exams; ?></h4>
                    <small>Total Exams</small>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stats-card p-3 text-center">
                    <i class="fas fa-users fa-2x mb-2"></i>
                    <h4><?php echo $total_students; ?></h4>
                    <small>Total Students</small>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stats-card p-3 text-center">
                    <i class="fas fa-clock fa-2x mb-2"></i>
                    <h4><?php echo $active_exams; ?></h4>
                    <small>Active Exams</small>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stats-card p-3 text-center">
                    <i class="fas fa-chart-line fa-2x mb-2"></i>
                    <h4><?php echo $avg_performance; ?>%</h4>
                    <small>Avg Performance</small>
                </div>
            </div>
        </div>

        <?php
        $latest_results = mysqli_query($conn, " SELECT * FROM results WHERE teacher_id='$teacher_id' 
            ORDER BY exam_id DESC
        ");
        ?>

        <div class="row mb-4">
            <div class="col-12">
                <div class="card shadow-sm">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="mb-0">Student Results</h5>
                            <small class="text-muted">Every student mark achieved on your exams</small>
                        </div>
                        <a href="system_analytics.php" class="btn btn-sm btn-outline-primary">View Analytics</a>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table align-middle mb-0 m-3">
                                <thead class="table-light">
                                    <tr>
                                        <th>Student</th>
                                        <th>Exam</th>
                                        <th>Score</th>
                                        <th>Percentage</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($latest_results && mysqli_num_rows($latest_results) > 0):
                                        while ($result_row = mysqli_fetch_assoc($latest_results)):
                                            $percentage = $result_row['total_questions'] > 0 ? round(($result_row['score'] / $result_row['total_questions']) * 100, 1) : 0;
                                            ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($result_row['Student_Name']); ?></td>
                                                <td><?php echo htmlspecialchars($result_row['Exam_Name']); ?></td>
                                                <td><?php echo htmlspecialchars($result_row['score']); ?>/<?php echo htmlspecialchars($result_row['total_questions']); ?>
                                                </td>
                                                <td><?php echo $percentage; ?>%</td>
                                                <td><?php echo date('d M Y', strtotime($result_row['submitted_at'] ?? 'now')); ?>
                                                </td>
                                            </tr>
                                        <?php endwhile;
                                    else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-4 text-muted">No recent results available
                                                yet.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row g-4 mb-5">

            <!-- Add Student -->
            <div class="col-md-3">
                <div class="dashboard-card text-center p-4">
                    <i class="fa fa-user-plus fa-3x text-primary mb-3"></i>
                    <h5>Add Student</h5>
                    <p class="text-muted small">Register new students</p>
                    <a href="add_Student.php" class="btn btn-primary w-100">
                        <i class="fas fa-plus me-1"></i>Open
                    </a>
                </div>
            </div>

            <!-- View Students -->
            <div class="col-md-3">
                <div class="dashboard-card text-center p-4">
                    <i class="fa fa-users fa-3x text-success mb-3"></i>
                    <h5>View Students</h5>
                    <p class="text-muted small">Manage student records</p>
                    <a href="view_students.php" class="btn btn-success w-100">
                        <i class="fas fa-eye me-1"></i>Open
                    </a>
                </div>
            </div>

            <!-- Create Exam -->
            <div class="col-md-3">
                <div class="dashboard-card text-center p-4">
                    <i class="fa fa-file-alt fa-3x text-warning mb-3"></i>
                    <h5>Create Exam</h5>
                    <p class="text-muted small">Design new examinations</p>
                    <a href="Create_Exam.php" class="btn btn-warning w-100">
                        <i class="fas fa-edit me-1"></i>Open
                    </a>
                </div>
            </div>

            <!-- Analytics -->
            <div class="col-md-3">
                <div class="dashboard-card text-center p-4">
                    <i class="fa fa-chart-bar fa-3x text-danger mb-3"></i>
                    <h5>Analytics</h5>
                    <p class="text-muted small">View system analytics</p>
                    <a href="system_analytics.php" class="btn btn-danger w-100">
                        <i class="fas fa-chart-pie me-1"></i>Open
                    </a>
                </div>
            </div>

            <!-- Settings -->
            <div class="col-md-3">
                <div class="dashboard-card text-center p-4">
                    <i class="fa fa-cog fa-3x text-secondary mb-3"></i>
                    <h5>Settings</h5>
                    <p class="text-muted small">System preferences</p>
                    <a href="settings.php" class="btn btn-secondary w-100">
                        <i class="fas fa-cog me-1"></i>Open
                    </a>
                </div>
            </div>

        </div>
        <div class="exam-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="mb-0">
                    <i class="fas fa-list me-2"></i>
                    Your Created Exams
                </h4>
                <a href="Create_Exam.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i>Create New Exam
                </a>
            </div>

            <div class="row">

                <?php if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {

                        // Get exam stats
                        $exam_stats = mysqli_query($conn, "
                            SELECT COUNT(*) as total_attempts,
                                   AVG((score/total_questions)*100) as avg_score,
                                   SUM(CASE WHEN (score/total_questions)*100 >= 40 THEN 1 ELSE 0 END) as pass_count
                            FROM results WHERE exam_id='{$row['id']}'
                        ");
                        if ($exam_stats) {
                            $stats = mysqli_fetch_assoc($exam_stats);
                        } else {
                            error_log('Teacher dashboard exam stats query failed for exam_id ' . $row['id'] . ': ' . mysqli_error($conn));
                            $stats = ['total_attempts' => 0, 'avg_score' => 0, 'pass_count' => 0];
                        }

                        $total_attempts = $stats['total_attempts'] ?? 0;
                        $avg_score = round($stats['avg_score'] ?? 0, 1);
                        $pass_rate = $total_attempts > 0 ? round(($stats['pass_count'] / $total_attempts) * 100, 1) : 0;

                        $exam_date = strtotime($row['exam_date'] . ' ' . $row['start_time']);
                        $now = time();
                        $status = $now < $exam_date ? 'Upcoming' : ($now > $exam_date + ($row['duration'] * 60) ? 'Completed' : 'Active');
                        $status_class = $status == 'Active' ? 'success' : ($status == 'Upcoming' ? 'warning' : 'secondary');
                        ?>

                        <div class="col-md-6 mb-4">
                            <div class="card shadow-sm h-100">
                                <div class="card-header bg-light">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h5 class="mb-0 text-primary">
                                            <?php echo htmlspecialchars($row['exam_name']); ?>
                                        </h5>
                                        <span class="badge bg-<?php echo $status_class; ?>"><?php echo $status; ?></span>
                                    </div>
                                </div>

                                <div class="card-body">
                                    <div class="row text-center mb-3">
                                        <div class="col-4">
                                            <div class="p-2 bg-light rounded">
                                                <strong><?php echo $total_attempts; ?></strong><br>
                                                <small class="text-muted">Attempts</small>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="p-2 bg-light rounded">
                                                <strong><?php echo $avg_score; ?>%</strong><br>
                                                <small class="text-muted">Avg Score</small>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="p-2 bg-light rounded">
                                                <strong><?php echo $pass_rate; ?>%</strong><br>
                                                <small class="text-muted">Pass Rate</small>
                                            </div>
                                        </div>
                                    </div>

                                    <p class="text-muted small mb-3">
                                        Date : <?php echo date("d M Y", $exam_date); ?><br>
                                        Timing : <?php echo date("h:i A", $exam_date); ?><br>
                                        Duration : <?php echo $row['duration']; ?> minutes
                                    </p>
                                    

                                    <div id="manage" class="d-flex flex-wrap gap-1">
                                        <a href="manage_exam.php?exam_id=<?php echo $row['id']; ?>"
                                            class="btn btn-sm btn-success">
                                            <i class="fas fa-edit me-1"></i>Manage
                                        </a>

                                        <a href="view_result.php?exam_id=<?php echo $row['id']; ?>"
                                            class="btn btn-sm btn-primary">
                                            <i class="fas fa-chart-bar me-1"></i>Results
                                        </a>

                                        <a href="analytics.php?exam_id=<?php echo $row['id']; ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye me-1"></i>Monitor
                                        </a>
                                    </div>

                                </div>
                            </div>
                        </div>

                    <?php }
                } else { ?>
                    <div class="alert alert-danger">
                        Unable to load exams. Please check database configuration or refresh the page.
                    </div>
                <?php } ?>

            </div>

            <?php if ($result && mysqli_num_rows($result) == 0) { ?>
                <div class="text-center py-5">
                    <i class="fas fa-book-open fa-4x text-muted mb-3"></i>
                    <h5 class="text-muted">No exams created yet</h5>
                    <p class="text-muted">Start by creating your first exam</p>
                    <a href="Create_Exam.php" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i>Create Your First Exam
                    </a>
                </div>
            <?php } ?>

        </div>
    </div>

    <script>
        let mange = document.getElementById('manage');

        if (<?php echo $status; ?> === 'Active') {
            mange.style.display = 'none';
        }

    </script>

    <?php include '../footer.html'; ?>
</body>

</html>