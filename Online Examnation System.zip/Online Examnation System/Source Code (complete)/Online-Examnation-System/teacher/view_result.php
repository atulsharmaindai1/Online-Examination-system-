<?php
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header("Location: teacher_login.php");
    exit();
}

include("conection.php");

if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: teacher_login.php");
    exit();
}

$exam_id = $_GET['exam_id'];

// Get exam details
$exam = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM exams WHERE id='$exam_id'"));

// Get results with student names
$results = mysqli_query($conn, "
    SELECT r.*, s.name as student_name
    FROM results r
    JOIN students s ON r.student_id = s.id
    WHERE r.exam_id='$exam_id'
    ORDER BY r.score DESC
");

$total_students = mysqli_num_rows($results);
$pass_count = 0;
$avg_score = 0;

if($total_students > 0){
    mysqli_data_seek($results, 0); // Reset pointer
    while($row = mysqli_fetch_assoc($results)){
        $percentage = ($row['score'] / $row['total_questions']) * 100;
        if($percentage >= 40) $pass_count++;
        $avg_score += $row['score'];
    }
    $avg_score = round($avg_score / $total_students, 2);
    mysqli_data_seek($results, 0); // Reset pointer again
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Results</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .result-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .stats-card {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 10px;
        }
    </style>
</head>
<body>

<?php
$nav_title = 'Exam Results';
include 'teacher_nav.php';
?>

<div class="container py-5">

    <!-- Header -->
    <div class="result-card p-4 mb-4">
        <div class="row">
            <div class="col-md-8">
                <h2 class="mb-2">📊 <?php echo htmlspecialchars($exam['exam_name']); ?> - Results</h2>
                <p class="text-muted mb-0">
                     Date: <?php echo date("d M Y", strtotime($exam['exam_date'])); ?> |
                     Duration: <?php echo $exam['duration']; ?> minutes |
                    📝 Total Questions: <?php echo $exam['total_questions'] ?? 'N/A'; ?>
                </p>
            </div>
            <div class="col-md-4 text-end">
                <a href="analytics.php?exam_id=<?php echo $exam_id; ?>" class="btn btn-warning">
                    <i class="fas fa-eye me-1"></i> Live Monitor
                </a>
            </div>
        </div>
    </div>

    <!-- Statistics -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="stats-card p-3 text-center">
                <h3><?php echo $total_students; ?></h3>
                <small>Total Students</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card p-3 text-center">
                <h3><?php echo $pass_count; ?></h3>
                <small>Passed</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card p-3 text-center">
                <h3><?php echo $total_students - $pass_count; ?></h3>
                <small>Failed</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card p-3 text-center">
                <h3><?php echo $avg_score; ?></h3>
                <small>Average Score</small>
            </div>
        </div>
    </div>

    <!-- Results Table -->
    <div class="result-card p-4">
        <h4 class="mb-3"> Student Results</h4>

        <?php if($total_students > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Rank</th>
                        <th>Student Name</th>
                        <th>Score</th>
                        <th>Percentage</th>
                        <th>Status</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $rank = 1;
                    while($row = mysqli_fetch_assoc($results)):
                        $percentage = round(($row['score'] / $row['total_questions']) * 100, 2);
                        $status = $percentage >= 40 ? 'PASS' : 'FAIL';
                        $status_class = $percentage >= 40 ? 'success' : 'danger';

                        // Grade calculation
                        if($percentage >= 90) $grade = 'A+';
                        elseif($percentage >= 80) $grade = 'A';
                        elseif($percentage >= 70) $grade = 'B+';
                        elseif($percentage >= 60) $grade = 'B';
                        elseif($percentage >= 50) $grade = 'C+';
                        elseif($percentage >= 40) $grade = 'C';
                        else $grade = 'F';
                    ?>
                    <tr>
                        <td><?php echo $rank++; ?></td>
                        <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                        <td><?php echo $row['score']; ?>/<?php echo $row['total_questions']; ?></td>
                        <td><?php echo $percentage; ?>%</td>
                        <td><span class="badge bg-<?php echo $status_class; ?>"><?php echo $status; ?></span></td>
                        <td><strong><?php echo $grade; ?></strong></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-chart-bar fa-3x text-muted mb-3"></i>
            <h5 class="text-muted">No results available yet</h5>
            <p class="text-muted">Students haven't taken this exam yet.</p>
        </div>
        <?php endif; ?>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include '../footer.html'; ?>
</body>
</html>