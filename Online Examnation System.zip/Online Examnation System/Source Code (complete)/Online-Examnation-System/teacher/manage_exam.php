<?php
session_start();
include("conection.php");

if (!isset($_SESSION['teacher_id'])) {
    header("Location: teacher_login.php");
    exit();
}
date_default_timezone_set("Asia/Kolkata");
$exam_id = $_GET['exam_id'];

//  Get Exam Details
$exam = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT * FROM exams WHERE id='$exam_id'"
    )
);
$_Start_time = strtotime($exam['start_time']." ".$exam['exam_date']);

// ✅ Update Exam Details (Reschedule)
if (isset($_POST['update_exam'])) {
    $name = $_POST['exam_name'];
    $date = $_POST['exam_date'];
    $duration = $_POST['duration'];
    $Start_time = strtotime($_POST['start_time']);

    mysqli_query($conn, "UPDATE exams SET 
        exam_name='$name', 
        exam_date='$date', 
        duration='$duration',
        start_time='$Start_time'
        WHERE id='$exam_id'");

    header("Location: manage_exam.php?exam_id=" . $exam_id);
    exit();
}


$now =strtotime(date("H:i:s")." ".date("Y-m-d"));


if ($now >= $_Start_time) {
    echo "Exam Started";
    header("Location: teacher_dashboard.php");
    exit();
}



// ✅ Add Question
if (isset($_POST['add_question'])) {
    $q = $_POST['question'];
    $o1 = $_POST['option1'];
    $o2 = $_POST['option2'];
    $o3 = $_POST['option3'];
    $o4 = $_POST['option4'];
    $correct = $_POST['correct_option'];

    mysqli_query($conn, "INSERT INTO questions 
    (exam_id, question, option1, option2, option3, option4, correct_option)
    VALUES ('$exam_id','$q','$o1','$o2','$o3','$o4','$correct')");
}

// ✅ Update Question
if (isset($_POST['update_question'])) {
    $qid = $_POST['qid'];
    $q = $_POST['question'];
    $o1 = $_POST['option1'];
    $o2 = $_POST['option2'];
    $o3 = $_POST['option3'];
    $o4 = $_POST['option4'];
    $correct = $_POST['correct_option'];

    mysqli_query($conn, "UPDATE questions SET 
        question='$q',
        option1='$o1',
        option2='$o2',
        option3='$o3',
        option4='$o4',
        correct_option='$correct'
        WHERE id='$qid'");
}

//  Delete Question
if (isset($_GET['delete_q'])) {
    $qid = $_GET['delete_q'];
    mysqli_query($conn, "DELETE FROM questions WHERE id='$qid'");
    header("Location: manage_exam.php?exam_id=" . $exam_id);
    exit();
}

//  Fetch Questions
$questions = mysqli_query($conn, "SELECT * FROM questions WHERE exam_id='$exam_id'");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Manage Exam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<?php
$nav_title = 'Manage Exam';
include 'teacher_nav.php';
?>

<body class="bg-light">

    <div class="container mt-5">

        <!--  Exam Details -->
        <div class="card p-4 mb-4 shadow">
            <h4> Edit Exam Details</h4>

            <form method="POST">
                <input type="text" name="exam_name" value="<?php echo $exam['exam_name']; ?>" class="form-control mb-2">
                <input type="date" name="exam_date" value="<?php echo $exam['exam_date']; ?>" class="form-control mb-2">
                <input type="number" name="duration" value="<?php echo $exam['duration']; ?>" class="form-control mb-3">

                <button type="submit" name="update_exam" class="btn btn-primary">
                    Update / Reschedule Exam
                </button>
            </form>
        </div>

        <!--  Add Question -->
        <div class="card p-4 mb-4 shadow">
            <h4>Add Question</h4>

            <form method="POST">
                <textarea name="question" class="form-control mb-2" placeholder="Question"></textarea>

                <input type="text" name="option1" class="form-control mb-2" placeholder="Option 1">
                <input type="text" name="option2" class="form-control mb-2" placeholder="Option 2">
                <input type="text" name="option3" class="form-control mb-2" placeholder="Option 3">
                <input type="text" name="option4" class="form-control mb-2" placeholder="Option 4">

                <select name="correct_option" class="form-control mb-2">
                    <option value="1">Correct: Option 1</option>
                    <option value="2">Correct: Option 2</option>
                    <option value="3">Correct: Option 3</option>
                    <option value="4">Correct: Option 4</option>
                </select>

                <button type="submit" name="add_question" class="btn btn-success">
                    Add Question
                </button>
            </form>
        </div>

        <!--  Questions List -->
        <div class="card p-4 shadow">
            <h4>Questions List</h4>

            <?php while ($row = mysqli_fetch_assoc($questions)) { ?>
                <form method="POST" class="border p-3 mb-3">

                    <input type="hidden" name="qid" value="<?php echo $row['id']; ?>">

                    <textarea name="question" class="form-control mb-2"><?php echo $row['question']; ?></textarea>

                    <input type="text" name="option1" value="<?php echo $row['option1']; ?>" class="form-control mb-2">
                    <input type="text" name="option2" value="<?php echo $row['option2']; ?>" class="form-control mb-2">
                    <input type="text" name="option3" value="<?php echo $row['option3']; ?>" class="form-control mb-2">
                    <input type="text" name="option4" value="<?php echo $row['option4']; ?>" class="form-control mb-2">

                    <select name="correct_option" class="form-control mb-2">
                        <option value="1" <?php if ($row['correct_option'] == 1)
                            echo "selected"; ?>>Option 1</option>
                        <option value="2" <?php if ($row['correct_option'] == 2)
                            echo "selected"; ?>>Option 2</option>
                        <option value="3" <?php if ($row['correct_option'] == 3)
                            echo "selected"; ?>>Option 3</option>
                        <option value="4" <?php if ($row['correct_option'] == 4)
                            echo "selected"; ?>>Option 4</option>
                    </select>

                    <button type="submit" name="update_question" class="btn btn-warning btn-sm">
                        Update
                    </button>

                    <a href="manage_exam.php?exam_id=<?php echo $exam_id; ?>&delete_q=<?php echo $row['id']; ?>"
                        class="btn btn-danger btn-sm" onclick="return confirm('Delete this question?')">
                        Delete
                    </a>

                </form>
            <?php } ?>

        </div>

    </div>

    <?php include '../footer.html'; ?>
</body>

</html>