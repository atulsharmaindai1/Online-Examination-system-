<?php
// Shared admin navigation bar
include("conection.php");
if (!isset($nav_title)) {
    $nav_title = 'Online Examination System';
}
if (!isset($nav_extra_button)) {
    $nav_extra_button = '';
}
?>


<nav class="navbar navbar-dark bg-dark px-4">
   
    <span class="navbar-brand fw-bold">
         <i class="fas fa-graduation-cap me-2"></i>
        <?php echo htmlspecialchars($nav_title); ?>
    </span>
    <?php if (isset($_SESSION['teacher_name'])): ?>
        <div class="text-white">
            <?php if (!empty($_SESSION['teacher_name'])): ?>
                Welcome, <?php echo htmlspecialchars($_SESSION['teacher_name']); ?> |
            <?php endif; ?>
            <a href="teacher_dashboard.php" class="btn btn-primary btn-sm ms-2">Dashboard</a>
            <?php if (!empty($nav_extra_button)): ?>
                <?php echo $nav_extra_button; ?>
            <?php endif; ?>

            <a href="teacher_logout.php" class="btn btn-danger btn-sm ms-2" name="logout">logout</a>

        </div>
    <?php endif; ?>
</nav>