<?php
include("conection.php");

$message = "";

// Run only on submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $dob = $_POST['dob'];

    // Check user
    $sql = "SELECT * FROM teachers WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);

        // Verify password
        if ($dob == $row['dob']) {

            // uppdate password
             $sql2 = "UPDATE teachers SET password = '$password' WHERE email = '$email'";
            mysqli_query($conn, $sql2);
            echo "<script>alert('Password updated successfully!');</script>";
            // Redirect to login
            header("Location: teacher_login.php");
            exit();
        } else {
            $message = "Wrong Date of Birth!";
        }
    } else {
        $message = "Email not found!";
    }
    echo "<script>alert('$message');</script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Teacher Login</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #1f4037, #99f2c8);
            height: 100vh;
        }

        /* Glass Card */
        .glass-card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            padding: 35px;
            color: white;
        }

        .form-control {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
        }

        .form-control::placeholder {
            color: #eee;
        }

        .form-control:focus {
            box-shadow: none;
            background: rgba(255, 255, 255, 0.3);
        }

        .btn-custom {
            border-radius: 30px;
            padding: 10px;
            font-size: 18px;
        }

        .icon {
            position: absolute;
            right: 15px;
            top: 12px;
            cursor: pointer;
        }
    </style>
</head>

<body>


    <!-- Navbar -->
     <?php
    $nav_title = 'Teacher Login';
    include 'teacher_nav.php';
    ?>
    <div class="container d-flex justify-content-center align-items-center" style="min-height:90vh;">

        <div class="glass-card col-md-6 col-lg-5 shadow-lg">
            <h3 class="text-center mb-4">Forgot Password</h3>

            <form method="POST">

                <div class="mb-3 position-relative">
                    <input type="email" name="email" class="form-control" placeholder="Enter Email" required>
                </div>

                <div class="mb-3 position-relative">
                    <input type="date" name="dob" class="form-control" placeholder="Enter Date of Birth" required>
                </div>

                <div class="mb-3 position-relative">
                    <input type="password" name="password" class="form-control" placeholder="Enter New Password" required>
                </div>

                <button type="submit" class="btn btn-success w-100">Reset Password</button>

            </form>
         
         </div>
    </div>
    <?php include '../footer.html'; ?>
</body>

</html>