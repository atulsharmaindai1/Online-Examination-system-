<?php
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header("Location: teacher_login.php");
    exit();
}

include("conection.php");
if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: teacher_login.php");
    exit();
}

$teacher_id = $_SESSION['teacher_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Analytics</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .analytics-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            backdrop-filter: blur(10px);
        }
        .metric-card {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 10px;
        }
    </style>
</head>
<body>

<?php
$nav_title = 'System Analytics';
include 'teacher_nav.php';
?>

<div class="container py-5">

    <div class="text-center mb-5">
        <h2 class="text-white">
            <i class="fas fa-chart-line me-2"></i>
            📊 System Analytics Dashboard
        </h2>
        <p class="text-white-50">Comprehensive insights into your examination system</p>
    </div>

    <!-- Key Metrics -->
    <div class="row mb-4">
        <?php
        // Total exams
        $total_exams = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM exams WHERE teacher_id='$teacher_id'"))['count'];

        // Total students who attempted exams
        $total_students = mysqli_fetch_assoc(mysqli_query($conn, "
            SELECT COUNT(DISTINCT r.student_id) as count
            FROM results r
            JOIN exams e ON r.exam_id = e.id
            WHERE e.teacher_id='$teacher_id'
        "))['count'];

        // Total exam attempts
        $total_attempts = mysqli_fetch_assoc(mysqli_query($conn, "
            SELECT COUNT(*) as count FROM results r
            JOIN exams e ON r.exam_id = e.id
            WHERE e.teacher_id='$teacher_id'
        "))['count'];

        // Average performance
        $avg_performance = mysqli_fetch_assoc(mysqli_query($conn, "
            SELECT AVG((r.score/r.total_questions)*100) as avg
            FROM results r
            JOIN exams e ON r.exam_id = e.id
            WHERE e.teacher_id='$teacher_id'
        "))['avg'];
        $avg_performance = round($avg_performance ?? 0, 1);

        // Pass rate
        $pass_stats = mysqli_fetch_assoc(mysqli_query($conn, "
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN (r.score/r.total_questions)*100 >= 40 THEN 1 ELSE 0 END) as passed
            FROM results r
            JOIN exams e ON r.exam_id = e.id
            WHERE e.teacher_id='$teacher_id'
        "));
        $pass_rate = $pass_stats['total'] > 0 ? round(($pass_stats['passed'] / $pass_stats['total']) * 100, 1) : 0;
        ?>
        <div class="col-md-3 mb-3">
            <div class="metric-card p-3 text-center">
                <i class="fas fa-book fa-2x mb-2"></i>
                <h4><?php echo $total_exams; ?></h4>
                <small>Total Exams Created</small>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="metric-card p-3 text-center">
                <i class="fas fa-users fa-2x mb-2"></i>
                <h4><?php echo $total_students; ?></h4>
                <small>Active Students</small>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="metric-card p-3 text-center">
                <i class="fas fa-clipboard-check fa-2x mb-2"></i>
                <h4><?php echo $total_attempts; ?></h4>
                <small>Total Attempts</small>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="metric-card p-3 text-center">
                <i class="fas fa-trophy fa-2x mb-2"></i>
                <h4><?php echo $pass_rate; ?>%</h4>
                <small>Overall Pass Rate</small>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Performance Chart -->
        <div class="col-md-6 mb-4">
            <div class="analytics-card p-4">
                <h5 class="mb-3">
                    <i class="fas fa-chart-bar me-2"></i>
                    Exam Performance Overview
                </h5>
                <canvas id="performanceChart"></canvas>
            </div>
        </div>

        <!-- Student Activity -->
        <div class="col-md-6 mb-4">
            <div class="analytics-card p-4">
                <h5 class="mb-3">
                    <i class="fas fa-user-clock me-2"></i>
                    Student Activity Trends
                </h5>
                <canvas id="activityChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="analytics-card p-4 mb-4">
        <h5 class="mb-3">
            <i class="fas fa-history me-2"></i>
            Recent Exam Activity
        </h5>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Exam Name</th>
                        <th>Date</th>
                        <th>Attempts</th>
                        <th>Avg Score</th>
                        <th>Pass Rate</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $recent_exams = mysqli_query($conn, "
                        SELECT e.exam_name, e.exam_date,
                               COUNT(r.id) as attempts,
                               AVG((r.score/r.total_questions)*100) as avg_score,
                               (SUM(CASE WHEN (r.score/r.total_questions)*100 >= 40 THEN 1 ELSE 0 END) / COUNT(r.id)) * 100 as pass_rate
                        FROM exams e
                        LEFT JOIN results r ON e.id = r.exam_id
                        WHERE e.teacher_id='$teacher_id'
                        GROUP BY e.id
                        ORDER BY e.exam_date DESC
                        LIMIT 10
                    ");

                    while($exam = mysqli_fetch_assoc($recent_exams)){
                        $avg_score = round($exam['avg_score'] ?? 0, 1);
                        $pass_rate = round($exam['pass_rate'] ?? 0, 1);
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($exam['exam_name']); ?></td>
                        <td><?php echo date("d M Y", strtotime($exam['exam_date'])); ?></td>
                        <td><?php echo $exam['attempts']; ?></td>
                        <td><?php echo $avg_score; ?>%</td>
                        <td><?php echo $pass_rate; ?>%</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Top Performers -->
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="analytics-card p-4">
                <h5 class="mb-3">
                    <i class="fas fa-star me-2"></i>
                    Top Performing Students
                </h5>
                <div class="list-group">
                    <?php
                    $top_students = mysqli_query($conn, "
                        SELECT s.name, AVG((r.score/r.total_questions)*100) as avg_score, COUNT(r.id) as exams_taken
                        FROM students s
                        JOIN results r ON s.id = r.student_id
                        JOIN exams e ON r.exam_id = e.id
                        WHERE e.teacher_id='$teacher_id'
                        GROUP BY s.id
                        ORDER BY avg_score DESC
                        LIMIT 5
                    ");

                    while($student = mysqli_fetch_assoc($top_students)){
                    ?>
                    <div class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <strong><?php echo htmlspecialchars($student['name']); ?></strong>
                            <br><small class="text-muted"><?php echo $student['exams_taken']; ?> exams taken</small>
                        </div>
                        <span class="badge bg-success rounded-pill"><?php echo round($student['avg_score'], 1); ?>%</span>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="analytics-card p-4">
                <h5 class="mb-3">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Students Needing Attention
                </h5>
                <div class="list-group">
                    <?php
                    $struggling_students = mysqli_query($conn, "
                        SELECT s.name, AVG((r.score/r.total_questions)*100) as avg_score, COUNT(r.id) as exams_taken
                        FROM students s
                        JOIN results r ON s.id = r.student_id
                        JOIN exams e ON r.exam_id = e.id
                        WHERE e.teacher_id='$teacher_id'
                        GROUP BY s.id
                        HAVING avg_score < 40
                        ORDER BY avg_score ASC
                        LIMIT 5
                    ");

                    while($student = mysqli_fetch_assoc($struggling_students)){
                    ?>
                    <div class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <strong><?php echo htmlspecialchars($student['name']); ?></strong>
                            <br><small class="text-muted"><?php echo $student['exams_taken']; ?> exams taken</small>
                        </div>
                        <span class="badge bg-danger rounded-pill"><?php echo round($student['avg_score'], 1); ?>%</span>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
// Performance Chart
const performanceCtx = document.getElementById('performanceChart').getContext('2d');
new Chart(performanceCtx, {
    type: 'bar',
    data: {
        labels: ['Average Score', 'Pass Rate', 'Total Attempts'],
        datasets: [{
            label: 'Performance Metrics',
            data: [<?php echo $avg_performance; ?>, <?php echo $pass_rate; ?>, <?php echo $total_attempts; ?>],
            backgroundColor: [
                'rgba(54, 162, 235, 0.8)',
                'rgba(75, 192, 192, 0.8)',
                'rgba(153, 102, 255, 0.8)'
            ],
            borderColor: [
                'rgba(54, 162, 235, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Activity Chart
const activityCtx = document.getElementById('activityChart').getContext('2d');
new Chart(activityCtx, {
    type: 'doughnut',
    data: {
        labels: ['Active Students', 'Total Students', 'Passed Students'],
        datasets: [{
            data: [<?php echo $total_students; ?>, <?php echo $total_students; ?>, <?php echo $pass_stats['passed']; ?>],
            backgroundColor: [
                'rgba(255, 206, 86, 0.8)',
                'rgba(54, 162, 235, 0.8)',
                'rgba(75, 192, 192, 0.8)'
            ],
            borderColor: [
                'rgba(255, 206, 86, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(75, 192, 192, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true
    }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include '../footer.html'; ?>
</body>
</html>