<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Examination System</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="introstyle.css">
    <style>
        body {
            background: linear-gradient(to right, #4facfe, #00f2fe);
            height: 100vh;
            color: #333;
        }

        .hero {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .card {
            border-radius: 15px;
            transition: 0.3s;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .btn-custom {
            width: 100%;
            border-radius: 25px;
        }

        #single {
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <!-- nav.html -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <span class="navbar-brand fw-bold">
                    <i class="fas fa-graduation-cap me-2"></i>
                    Online Examination System
                </span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="Student/Student_Login.php">Student Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="teacher/teacher_login.php">Teacher Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="container hero">
        <div class="row text-center w-100">

            <h1 class="mb-4">Welcome to Online Examination System</h1>
            <p class="mb-5 text-muted">Choose your role to continue</p>

            <!-- Student Card -->
            <div class="col-md-6 mb-3">
                <div class="card shadow p-4">
                    <h3> Student</h3>
                    <p>Attempt exams, view results, and track your performance.</p>
                    <p>learn toady lead tomorrow</p>

                    <a href="Student/Student_Login.php" id="single" class="btn btn-primary btn-custom">
                        Student Login
                    </a>

                </div>
            </div>

            <!-- Teacher Card -->
            <div class="col-md-6 mb-3">
                <div class="card shadow p-4">
                    <h3>Teacher</h3>
                    <p>Add Student,Create exams, manage questions,and check student results.</p>

                    <a href="teacher/teacher_Login.php" class="btn btn-success btn-custom">
                        Teacher Login
                    </a>

                    <a href="teacher/teacher_Register.php" class="btn btn-outline-success btn-custom mt-2">
                        Teacher Register
                    </a>
                </div>
            </div>

        </div>
    </div>
</body>
<?php include 'footer.html'; ?>
</html>