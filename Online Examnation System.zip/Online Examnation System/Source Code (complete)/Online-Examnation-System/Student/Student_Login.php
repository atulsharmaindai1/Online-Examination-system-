<?php
session_start();
include("../teacher/conection.php");


$message = "";

// Run only on submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $sid = mysqli_real_escape_string($conn, $_POST['SID']);
    $password = $_POST['spassword'];

    $sql = "SELECT * FROM students WHERE id='$sid'";
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("Query Error: " . mysqli_error($conn));
    }

    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_assoc($result);

        if (password_verify($password, $row['password'])) {

            $_SESSION['student_id'] = $row['id'];
            $_SESSION['student_name'] = $row['name'];
            $_SESSION['teacher_id'] = $row['teacher_id'];

            header("Location: Student_Dashboard.php");
            exit();

        } else {
            $message = "Wrong Password!";
        }

    } else {
        $message = "Student ID not found!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Student Login</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #211f40, #ba99f2);
            height: 100vh;
        }

        /* Glass Card */
        .glass-card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            padding: 35px;
            color: white;
        }

        .form-control {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
        }

        .form-control::placeholder {
            color: #eee;
        }

        .form-control:focus {
            box-shadow: none;
            background: rgba(255, 255, 255, 0.3);
        }

        .btn-custom {
            border-radius: 30px;
            padding: 10px;
            font-size: 18px;
        }

        .icon {
            position: absolute;
            right: 15px;
            top: 12px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <?php include("nav_student.php");
     ?>
    <!-- 🔥 Form -->

    <div class="container d-flex justify-content-center align-items-center" style="min-height:90vh;">

        <div class="glass-card col-md-6 col-lg-5 shadow-lg">

      <h2 class="text-center mb-4">  Student Login</h2>

<?php if($message != ""){ ?>
    <div class="alert alert-danger text-center">
        <?php echo $message; ?>
    </div>
            <?php if($message != ""){ ?>
    <div class="alert alert-danger text-center">
        <?php echo $message; ?>
    </div>
<?php } ?>
<?php } ?>

            <form action="Student_Login.php" method="POST">

                <!-- Name -->
                <div class="mb-3 position-relative">
                    <input type="text" name="SID" class="form-control" placeholder="Student Id" required>
                    <i class="fa fa-user icon"></i>
                </div>

                <!-- Password -->
                <div class="mb-3 position-relative">
                    <input type="password" id="spassword" name="spassword" class="form-control" placeholder="Password"
                        required>
                    <i class="fa fa-eye icon" onclick="togglePassword()"></i>
                </div>

                <!-- Button -->
                <button type="submit" class="btn btn-success w-100 btn-custom">
                    Login
                </button>

            </form>

        </div>

    </div>

    <!-- JS -->
    <script>
        function togglePassword() {
            let pass = document.getElementById("spassword");
            pass.type = pass.type === "password" ? "text" : "password";
        }
    
  setTimeout(() => {
      let alertBox = document.querySelector('.alert');
      if(alertBox){
        alertBox.style.display = 'none';
      }
         }, 3000);

    </script>

    <?php include '../footer.html'; ?>
</body>

</html>