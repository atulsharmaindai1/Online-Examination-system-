<?php
session_start();
include("../teacher/conection.php");

$exam_id = intval($_POST['exam_id'] ?? 0);
$warnings = intval($_POST['warnings'] ?? 0);
$student_id = $_SESSION['student_id'] ?? 0;

if (!$student_id || !$exam_id) {
    http_response_code(400);
    echo 'Missing student or exam session.';
    exit;
}

// Update or insert activity
$result = mysqli_query($conn, "SELECT id FROM activity WHERE student_id='$student_id' AND exam_id='$exam_id'");

if ($result && mysqli_num_rows($result) > 0) {
    mysqli_query($conn, "UPDATE activity SET warnings='$warnings', last_activity=NOW() WHERE student_id='$student_id' AND exam_id='$exam_id'");
} else {
    mysqli_query($conn, "INSERT INTO activity (student_id, exam_id, warnings, last_activity) VALUES ('$student_id', '$exam_id', '$warnings', NOW())");
}
?>