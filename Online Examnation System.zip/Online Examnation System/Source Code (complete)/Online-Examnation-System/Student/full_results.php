<?php
session_start();

if (!isset($_SESSION['student_id'])) {
    header("Location: Student_Login.php");
    exit();
}

include("../Teacher/conection.php");
$student_id = $_SESSION['student_id'];

// Get all results with exam details
$results = mysqli_query($conn, "
    SELECT r.*, e.exam_name, e.exam_date
    FROM results r
    JOIN exams e ON r.exam_id = e.id
    WHERE r.student_id='$student_id'
    ORDER BY e.exam_date DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Results</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .result-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            backdrop-filter: blur(10px);
        }
        .performance-card {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 10px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-dark bg-dark px-4">
    <span class="navbar-brand fw-bold">
        <i class="fas fa-chart-bar me-2"></i>
        My Examination Results
    </span>
    <div class="text-white">
        Welcome, <?php echo $_SESSION['student_name']; ?> |
        <a href="student_dashboard.php" class="btn btn-primary btn-sm ms-2">Dashboard</a>
        <a href="logout.php" class="btn btn-danger btn-sm ms-2">Logout</a>
    </div>
</nav>

<div class="container py-5">

    <div class="text-center mb-5">
        <h2 class="text-white">
            <i class="fas fa-trophy me-2"></i>
             My Examination Results
        </h2>
        <p class="text-white-50">Detailed view of all your exam performances</p>
    </div>

    <?php if(mysqli_num_rows($results) > 0): ?>

    <!-- Overall Statistics -->
    <div class="row mb-4">
        <?php
        $total_exams = mysqli_num_rows($results);
        $total_score = 0;
        $passed_exams = 0;
        $highest_score = 0;
        $lowest_score = 100;

        mysqli_data_seek($results, 0);
        while($res = mysqli_fetch_assoc($results)){
            $percentage = ($res['score'] / $res['total_questions']) * 100;
            $total_score += $percentage;
            $highest_score = max($highest_score, $percentage);
            $lowest_score = min($lowest_score, $percentage);
            if($percentage >= 40) $passed_exams++;
        }
        $avg_score = round($total_score / $total_exams, 1);
        mysqli_data_seek($results, 0);
        ?>
        <div class="col-md-3 mb-3">
            <div class="performance-card p-3 text-center">
                <i class="fas fa-book fa-2x mb-2"></i>
                <h4><?php echo $total_exams; ?></h4>
                <small>Total Exams</small>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="performance-card p-3 text-center">
                <i class="fas fa-chart-line fa-2x mb-2"></i>
                <h4><?php echo $avg_score; ?>%</h4>
                <small>Average Score</small>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="performance-card p-3 text-center">
                <i class="fas fa-trophy fa-2x mb-2"></i>
                <h4><?php echo $highest_score; ?>%</h4>
                <small>Highest Score</small>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="performance-card p-3 text-center">
                <i class="fas fa-check-circle fa-2x mb-2"></i>
                <h4><?php echo $passed_exams; ?>/<?php echo $total_exams; ?></h4>
                <small>Passed Exams</small>
            </div>
        </div>
    </div>

    <!-- Results List -->
    <div class="result-card p-4">
        <h4 class="mb-4">
            <i class="fas fa-list me-2"></i>
            Detailed Results
        </h4>

        <div class="row">
            <?php while($res = mysqli_fetch_assoc($results)):
                $percentage = round(($res['score'] / $res['total_questions']) * 100, 1);
                $status = $percentage >= 40 ? 'PASS' : 'FAIL';
                $status_class = $percentage >= 40 ? 'success' : 'danger';
                $progress_class = $percentage >= 80 ? 'bg-success' : ($percentage >= 60 ? 'bg-info' : ($percentage >= 40 ? 'bg-warning' : 'bg-danger'));
            ?>
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header bg-light">
                        <div class="d-flex justify-content-between align-items-center">
                            <h6 class="mb-0 text-primary"><?php echo htmlspecialchars($res['exam_name']); ?></h6>
                            <span class="badge bg-<?php echo $status_class; ?>"><?php echo $status; ?></span>
                        </div>
                        <small class="text-muted">
                             <?php echo date("d M Y", strtotime($res['exam_date'])); ?>
                        </small>
                    </div>

                    <div class="card-body">
                        <!-- Score Display -->
                        <div class="text-center mb-3">
                            <h3 class="text-<?php echo $status_class; ?> mb-0"><?php echo $percentage; ?>%</h3>
                            <small class="text-muted">
                                <?php echo $res['score']; ?>/<?php echo $res['total_questions']; ?> correct answers
                            </small>
                        </div>

                        <!-- Progress Bar -->
                        <div class="mb-3">
                            <div class="progress">
                                <div class="progress-bar <?php echo $progress_class; ?>"
                                     role="progressbar"
                                     style="width: <?php echo $percentage; ?>%"
                                     aria-valuenow="<?php echo $percentage; ?>"
                                     aria-valuemin="0"
                                     aria-valuemax="100">
                                </div>
                            </div>
                        </div>

                        <!-- Performance Message -->
                        <div class="text-center">
                            <?php if($percentage >= 90): ?>
                                <small class="text-success"><i class="fas fa-star me-1"></i>Outstanding!</small>
                            <?php elseif($percentage >= 75): ?>
                                <small class="text-info"><i class="fas fa-thumbs-up me-1"></i>Great job!</small>
                            <?php elseif($percentage >= 60): ?>
                                <small class="text-primary"><i class="fas fa-check me-1"></i>Good work!</small>
                            <?php elseif($percentage >= 40): ?>
                                <small class="text-warning"><i class="fas fa-exclamation-triangle me-1"></i>Passed</small>
                            <?php else: ?>
                                <small class="text-danger"><i class="fas fa-times me-1"></i>Needs improvement</small>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>

    <?php else: ?>
    <div class="result-card p-5 text-center">
        <i class="fas fa-chart-bar fa-4x text-muted mb-3"></i>
        <h4 class="text-muted">No Results Available</h4>
        <p class="text-muted">You haven't taken any exams yet. Start with your first exam to see results here!</p>
        <a href="student_dashboard.php" class="btn btn-primary">
            <i class="fas fa-arrow-left me-1"></i>Back to Dashboard
        </a>
    </div>
    <?php endif; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <?php include '../footer.html'; ?>
</body>
</html>