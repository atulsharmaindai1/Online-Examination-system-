<!-- 🔝 Navbar -->
<?php

// Shared Student navigation bar
if (!isset($nav_title)) {
    $nav_title = 'Online Examination System';
}
if (!isset($nav_extra_button)) {
    $nav_extra_button = '';
}
?>


<nav class="navbar navbar-dark bg-dark px-4">
    
    <span class="navbar-brand fw-bold">
        <i class="fas fa-graduation-cap me-2"></i>
        <?php echo htmlspecialchars($nav_title); ?>
    </span>
    <?php if(isset($_SESSION['student_name'])): ?>
    <div class="text-white">
        <?php if (!empty($_SESSION['student_name'])): ?>
            Welcome, <?php echo htmlspecialchars($_SESSION['student_name']); ?> |
        <?php endif; ?>
        <a href="Student_Dashboard.php" class="btn btn-primary btn-sm ms-2">Dashboard</a>
        <?php if (!empty($nav_extra_button)): ?>
            <?php echo $nav_extra_button; ?>
        <?php endif; ?>
       
            <a href="logout.php" class="btn btn-danger btn-sm ms-2" name="logout">logout</a>
    
    </div>
     <?php endif; ?>
</nav>
