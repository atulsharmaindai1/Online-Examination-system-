<?php
session_start();
session_destroy();
header("Location: Student_Login.php");
exit();
?>