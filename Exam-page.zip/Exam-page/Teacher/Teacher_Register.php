<?php
include("conection.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Teacher Register</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #1f4037, #99f2c8);
            height: 100vh;
        }

        /* Glass Card */
        .glass-card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            padding: 35px;
            color: white;
        }

        .form-control {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
        }

        .form-control::placeholder {
            color: #eee;
        }

        .form-control:focus {
            box-shadow: none;
            background: rgba(255, 255, 255, 0.3);
        }

        .btn-custom {
            border-radius: 30px;
            padding: 10px;
            font-size: 18px;
        }

        .icon {
            position: absolute;
            right: 15px;
            top: 12px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <?php
    include("teacher_nav.php");
    ?>
    <!-- 🔥 Form -->

    <div class="container d-flex justify-content-center align-items-center" style="min-height: 90vh;">

        <div class="glass-card col-md-6 col-lg-5 shadow-lg">

            <h2 class="text-center mb-4"> Teacher Registration</h2>

            <form action="Teacher_Register.php" method="POST"  id="RegisterForm">

                <!-- Name -->
                <div class="mb-3 position-relative">
                    <input type="text" name="name" class="form-control" placeholder="Full Name" required>
                    <i class="fa fa-user icon"></i>
                </div>

                <!-- Email -->
                <div class="mb-3 position-relative">
                    <input type="email" name="email" class="form-control" placeholder="Email Address" required>
                    <i class="fa fa-envelope icon"></i>
                </div>
                 <!-- date of birth -->
                <div class="mb-3 position-relative">
                    <input type="date" id="dob" name="dob" class="form-control" placeholder="Date of Birth" required>
                </div>

                <!-- Password -->
                <div class="mb-3 position-relative">
                    <input type="password" id="password" name="password" class="form-control" placeholder="Password"
                        required>
                    <i class="fa fa-eye icon" onclick="togglePassword()"></i>
                </div>
               

                <!-- Confirm Password -->
                <div class="mb-3 position-relative">
                    <input type="password" id="confirmPassword" class="form-control" placeholder="Confirm Password"
                        required>
                </div>

                <!-- Button -->
                <button type="submit" class="btn btn-success w-100 btn-custom">
                    Register
                </button>

            </form>

            <p class="text-center mt-3">
                Already have an account? <a href="teacher_login.php" class="text-white">Login</a>
            </p>

        </div>

    </div>

    <!-- JS -->
    <script>
        document.getElementById("registerForm").addEventListener("submit", function (e) {
            e.preventDefault();

            let name = document.getElementById("name").value;
            let email = document.getElementById("email").value;
            let password = document.getElementById("password").value;

            if (name === "" || email === "" || password === "") {
                document.getElementById("msg").innerText = "All fields required";
                return;
            }

            fetch("api/Teacher_Register.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: "name=" + name + "&email=" + email + "&password=" + password
            })
                .then(res => res.text())
                .then(data => {
                    if (data === "success") {
                        document.getElementById("msg").innerText = "Registration Successful";
                    } else {
                        document.getElementById("msg").innerText = data;
                    }
                });
        });
    </script>

    <?php include '../footer.html'; ?>
<?php


$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];  
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $check = "SELECT * FROM teachers WHERE email='$email'";
    $result = mysqli_query($conn, $check);

    if (mysqli_num_rows($result) > 0) {
        $message = "Email already exists!";
    } else {
        $sql = "INSERT INTO teachers (name, email, password, dob)
                VALUES ('$name', '$email', '$password', '$dob')";

        if (mysqli_query($conn, $sql)) {
            $message = "Registration Successful!";
            echo "<script>
        alert('Registration Successful!');
        window.location.href='teacher_login.php';
        </script>";
        } else {
            $message = "Error occurred!";
        }
    }
    echo "<script>alert('$message');</script>";
}
?>