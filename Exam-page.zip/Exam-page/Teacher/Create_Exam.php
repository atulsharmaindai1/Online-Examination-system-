<?php
session_start();
include("conection.php");

//  Protect
if (!isset($_SESSION['teacher_id'])) {
    header("Location: teacher_login.php");
    exit();
}

$exam_id = $_GET['exam_id'] ?? null;

//  Step 1: Create Exam
if (isset($_POST['create_exam'])) {
    $teacher_id = $_SESSION['teacher_id'];
    $name = $_POST['exam_name'];
    $date = $_POST['exam_date'];
    $duration = $_POST['duration'];
    $Start_time = $_POST['Set_time'];

    mysqli_query($conn, "INSERT INTO exams (teacher_id, exam_name, exam_date, duration,start_time)
    VALUES ('$teacher_id','$name','$date','$duration','$Start_time')");

    $new_id = mysqli_insert_id($conn);

    header("Location: create_exam.php?exam_id=" . $new_id);
    exit();
}

//  Step 2: Add Question
if (isset($_POST['add_question'])) {
    $exam_id = $_POST['exam_id'];
    $q = $_POST['question'];
    $o1 = $_POST['option1'];
    $o2 = $_POST['option2'];
    $o3 = $_POST['option3'];
    $o4 = $_POST['option4'];
    $correct = $_POST['correct_option'];

    mysqli_query($conn, "INSERT INTO questions 
    (exam_id, question, option1, option2, option3, option4, correct_option)
    VALUES ('$exam_id','$q','$o1','$o2','$o3','$o4','$correct')");
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Create Exam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   
</head>

<body class="bg-light">
    <?php
    $nav_title = 'Create Exam';
    include 'teacher_nav.php';
    ?>
    <div class="container mt-5">

        <!--  Step 1: CREATE EXAM (TOP ALWAYS) -->
        <div class="card p-4 mb-4 shadow">
            <h4>Create Exam</h4>

            <form method="POST">
                <input type="text" name="exam_name" class="form-control mb-2" placeholder="Exam Name" required>
                <input type="date" name="exam_date" class="form-control mb-2" required>
                <input type="number" name="duration" class="form-control mb-3" placeholder="duration (minutes)"
                    required>
                <input type="time" name="Set_time" class="form-control mb-3" placeholder="Start On" required>

                <button type="submit" name="create_exam" class="btn btn-primary">
                    Create Exam
                </button>
            </form>
        </div>

        <!--  Step 2: SHOW AFTER CREATE -->
        <?php if ($exam_id) { ?>

            <div class="card p-4 shadow">

                <h4>Add / Edit Questions</h4>

                <!-- Add Question -->
                <form method="POST" class="mb-4">

                    <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">

                    <textarea name="question" class="form-control mb-2" placeholder="Question" required></textarea>

                    <input type="text" name="option1" class="form-control mb-2" placeholder="Option 1" required>
                    <input type="text" name="option2" class="form-control mb-2" placeholder="Option 2" required>
                    <input type="text" name="option3" class="form-control mb-2" placeholder="Option 3" required>
                    <input type="text" name="option4" class="form-control mb-2" placeholder="Option 4" required>

                    <select name="correct_option" class="form-control mb-2">
                        <option value="1">Correct: Option 1</option>
                        <option value="2">Correct: Option 2</option>
                        <option value="3">Correct: Option 3</option>
                        <option value="4">Correct: Option 4</option>
                    </select>

                    <button type="submit" name="add_question" class="btn btn-success">
                        Add Question
                    </button>
                </form>

                <!--  Show Questions -->
                <h5>Questions List</h5>

                <?php
                $result = mysqli_query($conn, "SELECT * FROM questions WHERE exam_id='$exam_id'");
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="border p-2 mb-2">
                        <b>Q:<?php echo $row['id'] ?></b> <?php echo $row['question'] ?><br>
                        1. <?php echo $row['option1']; ?><br>
                        2. <?php echo $row['option2']; ?><br>
                        3. <?php echo $row['option3']; ?><br>
                        4. <?php echo $row['option4']; ?><br>
                        <b>Correct:</b> Option <?php echo $row['correct_option']; ?>
                    </div>
                <?php } ?>

                <!--  FINAL SUBMIT -->
                <a href="teacher_dashboard.php" class="btn btn-primary mt-3">
                    Finish & Go Dashboard
                </a>

            </div>

        <?php } ?>

    </div>

    <?php include '../footer.html'; ?>
</body>

</html>