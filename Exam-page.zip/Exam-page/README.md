# Online Examination System

A comprehensive web-based examination platform built with PHP, MySQL, Bootstrap, and JavaScript. This system allows teachers to create and manage exams, while students can take exams with real-time monitoring and proctoring features.

## 🚀 Features

### For Teachers
- **Secure Login System** - Password-protected teacher accounts
- **Exam Management** - Create, edit, and delete exams with multiple-choice questions
- **Student Management** - Add and view student records
- **Real-time Monitoring** - Activity tracking during exams
- **Analytics Dashboard** - Comprehensive analytics with charts and performance metrics
- **Results Management** - View detailed exam results and student performance
- **Anti-cheating Features** - Tab switching detection and inactivity monitoring

### For Students
- **User-friendly Dashboard** - Clean interface showing available exams and results
- **Real-time Exam Timer** - Automatic submission when time expires
- **Detailed Results** - Comprehensive result pages with performance analysis
- **Progress Tracking** - Visual progress indicators and countdown timers
- **Secure Exam Environment** - Activity restrictions and exam integrity checks

### System Features
- **Responsive Design** - Works on desktop, tablet, and mobile devices
- **Real-time Updates** - Live monitoring and status updates
- **Data Visualization** - Charts and graphs for performance analytics
- **Security Features** - Session management and input validation
- **Modern UI/UX** - Beautiful gradient backgrounds and card-based layouts

## 🛠️ Technology Stack

- **Backend**: PHP 7+
- **Database**: MySQL
- **Frontend**: HTML5, CSS3, Bootstrap 5, JavaScript
- **Charts**: Chart.js
- **Icons**: Font Awesome 6

## 📁 Project Structure

```
Exam-page/
├── index.php                 # Homepage
├── header.html              # HTML head and navigation
├── nav.html                 # Navigation bar
├── Intro.html               # Landing page content
├── footer.html               # footer and scripts
├── introstyle.css           # Homepage styles
├── README.md                # This file
├── Admin/                   # Teacher panel
│   ├── teacher_login.php       # Teacher login
│   ├── teacher_dashboard.php # Teacher dashboard
│   ├── Create_Exam.php      # Create new exams
│   ├── manage_exam.php      # Edit existing exams
│   ├── view_result.php      # View exam results
│   ├── analytics.php        # Live monitoring
│   ├── system_analytics.php # Analytics dashboard
│   ├── addStudent.php       # Add students
│   ├── view_students.php    # View student list
│   ├── delete_exam.php      # Delete exams
│   ├── monitor_data.php     # AJAX data for monitoring
│   ├── get_alerts.php       # Live alerts
│   ├── terminate.php        # Terminate student exam
│   └── conection.php        # Database connection
└── Student/                 # Student panel
    ├── Student_Login.php     # Student login
    ├── student_dashboard.php  # Student dashboard
    ├── exam.php             # Exam interface
    ├── result.php           # Individual result page
    ├── full_results.php     # All results page
    ├── submit_exam.php      # Exam submission
    ├── logout.php           # Student logout
    ├── activity.php         # Activity tracking
    ├── send_alert.php       # Send alerts
    └── check_terminate.php  # Check termination
```

## 🗄️ Database Schema

### Tables Required:
- `teachers` - Teacher accounts
- `students` - Student accounts
- `exams` - Exam information
- `questions` - Exam questions
- `results` - Exam results
- `activity` - Student activity during exams
- `alerts` - Proctoring alerts

### Sample SQL:
```sql
CREATE TABLE teachers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255)
);

CREATE TABLE students (
    id INT PRIMARY KEY,
    name VARCHAR(100),
    password VARCHAR(255),
    teacher_id INT
);

CREATE TABLE exams (
    id INT PRIMARY KEY AUTO_INCREMENT,
    teacher_id INT,
    exam_name VARCHAR(200),
    exam_date DATE,
    start_time TIME,
    duration INT,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id)
);

CREATE TABLE questions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    exam_id INT,
    question TEXT,
    option1 VARCHAR(500),
    option2 VARCHAR(500),
    option3 VARCHAR(500),
    option4 VARCHAR(500),
    correct_option INT,
    FOREIGN KEY (exam_id) REFERENCES exams(id)
);

CREATE TABLE results (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT,
    exam_id INT,
    score INT,
    total_questions INT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (exam_id) REFERENCES exams(id)
);

CREATE TABLE activity (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT,
    exam_id INT,
    warnings INT DEFAULT 0,
    terminated BOOLEAN DEFAULT FALSE,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (exam_id) REFERENCES exams(id)
);

CREATE TABLE alerts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT,
    exam_id INT,
    message TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (exam_id) REFERENCES exams(id)
);

```

## 🚀 Installation & Setup

1. **Prerequisites**:
   - XAMPP/WAMP or any PHP server
   - MySQL database
   - Web browser with JavaScript enabled

2. **Setup Steps**:
   - Clone/download the project to your web server root
   - Create a MySQL database named `online_exam`
   - Import the database schema from above
   - Update database credentials in connection files if needed
   - Start your web server

3. **Default Access**:
   - **Homepage**: `http://localhost/Exam-page/`
   - **Teacher Login**: `http://localhost/Exam-page/Admin/teacher_login.php`
   - **Student Login**: `http://localhost/Exam-page/Student/Student_Login.php`

##  Security Features

- Password hashing with PHP's `password_hash()`
- Session-based authentication
- Input validation and sanitization
- SQL injection prevention with prepared statements
- XSS protection
- CSRF protection on forms

## 📱 Responsive Design

The system is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile phones
- Different screen sizes and orientations

## 🎨 UI/UX Features

- Modern gradient backgrounds
- Card-based layouts
- Smooth animations and transitions
- Intuitive navigation
- Color-coded status indicators
- Progress bars and visual feedback
- Mobile-friendly touch interfaces

## 🔍 Monitoring & Proctoring

- **Tab Switching Detection**: Alerts when students switch tabs
- **Inactivity Monitoring**: Detects when students are away
- **Activity Logging**: Tracks all student actions
- **Live Alerts**: Real-time notifications to teachers
- **Auto-termination**: Ability to end exams remotely

## 📊 Analytics & Reporting

- **Performance Charts**: Visual representation of results
- **Student Rankings**: Leaderboards and comparisons
- **Pass/Fail Statistics**: Success rate analysis
- **Time-based Analytics**: Performance over time
- **Detailed Reports**: Individual and group insights

## 🔧 Customization Options

- **Themes**: Easily customizable color schemes
- **Question Types**: Extensible for different question formats
- **Time Limits**: Configurable exam durations
- **Scoring Systems**: Flexible grading options
- **Notification Settings**: Customizable alerts and messages

## 🐛 Troubleshooting

### Common Issues:
1. **Database Connection Errors**: Check database credentials and server status
2. **Browser Permission Issues**: Ensure the browser has access to required features and no extensions block execution
3. **JavaScript Errors**: Check browser console, ensure all files are loaded
4. **Session Issues**: Clear browser cookies, check PHP session configuration

### Debug Mode:
- Enable error reporting in PHP for development
- Check browser developer tools for JavaScript errors
- Monitor network requests for AJAX calls

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is open source and available under the MIT License.

## 📞 Support

For support or questions, please check the troubleshooting section or create an issue in the repository.

---

**Note**: This system includes proctoring features. Ensure compliance with local privacy laws and obtain consent when monitoring exam activity.
