<?php
session_start();

if (!isset($_SESSION['student_id'])) {
    header("Location: Student_Login.php");
    exit();
}

$conn = mysqli_connect("localhost","root","","online_exam");

$exam_id = intval($_POST['exam_id'] ?? 0);
$student_id = $_SESSION['student_id'];
$student_name = $_SESSION['student_name'];
$answers = $_POST['answer'] ?? [];
$current_exam = $_SESSION['current_exam'] ?? null;
$teacher_id = $_SESSION['teacher_id'] ?? null;

if (!$exam_id) {
    header("Location: student_dashboard.php");
    exit();
}

// Prevent duplicate submission
$existing = mysqli_query($conn, "SELECT id FROM results WHERE student_id='$student_id' AND exam_id='$exam_id' ");
if ($existing === false) {
    echo 'Database error: ' . mysqli_error($conn);
    exit();
}
if (mysqli_num_rows($existing) > 0) {
    header("Location: result.php?exam_id=$exam_id");
    exit();
}

// Check if terminated
$term_check = mysqli_query($conn, "SELECT `terminated` FROM activity WHERE student_id='$student_id' AND exam_id='$exam_id'");
if ($term_check === false) {
    echo 'Database error: ' . mysqli_error($conn);
    exit();
}
if (mysqli_num_rows($term_check) > 0) {
    $row = mysqli_fetch_assoc($term_check);
    if ($row['terminated'] == 1) {
        header("Location: student_dashboard.php");
        exit();
    }
}

// Get questions
$questions = mysqli_query($conn, "SELECT * FROM questions WHERE exam_id='$exam_id'");
if ($questions === false) {
    echo 'Database error: ' . mysqli_error($conn);
    exit();
}
$score = 0;
$total_questions = mysqli_num_rows($questions);
if ($total_questions === 0) {
    echo 'No questions found for this exam.';
    exit();
}

// Calculate score
while($q = mysqli_fetch_assoc($questions)){
    $qid = $q['id'];
    $correct = $q['correct_option'];
    $user_answer = $answers[$qid] ?? 0;

    if($user_answer == $correct){
        $score++;
    }
}
echo "Calculated Score: $score / $total_questions";
// Save result
$insert = mysqli_query($conn, "INSERT INTO results (student_id, exam_id,teacher_id, score, total_questions,Exam_name,student_name,submitted_at) VALUES ('$student_id', '$exam_id', '$teacher_id', '$score', '$total_questions','$current_exam','$student_name', NOW())");
if (!$insert) {
    $error = mysqli_error($conn);
    if (strpos($error, "Unknown column 'score' in 'field list'") !== false || strpos($error, "Unknown column 'total_questions' in 'field list'") !== false) {
        mysqli_query($conn, "ALTER TABLE results ADD COLUMN IF NOT EXISTS score INT NOT NULL DEFAULT 0 AFTER exam_id");
        mysqli_query($conn, "ALTER TABLE results ADD COLUMN IF NOT EXISTS total_questions INT NOT NULL DEFAULT 0 AFTER score");
        $insert = mysqli_query($conn, "INSERT INTO results (student_id, exam_id, score, total_questions) VALUES ('$student_id', '$exam_id', '$score', '$total_questions')");
        if (!$insert) {
            echo 'Database error after repair: ' . mysqli_error($conn);
            exit();
        }
    } else {
        echo 'Database error: ' . $error;
        exit();
    }
}

$folderName = preg_replace('/[^a-zA-Z0-9_]/', '_', $student_name);

$path = "../camera-system/uploads/" . $folderName;
deleteFolder($path);
function deleteFolder($folder) {
    if (!is_dir($folder)) {
        return false;
    }

    $files = scandir($folder);

    foreach ($files as $file) {
        if ($file != "." && $file != "..") {
            $fullPath = $folder . "/" . $file;

            if (is_dir($fullPath)) {
                deleteFolder($fullPath);
            } else {
                unlink($fullPath);
            }
        }
    }

    return rmdir($folder);
}


// Clear activity data
mysqli_query($conn, "DELETE FROM activity WHERE student_id='$student_id' AND exam_id='$exam_id'");
mysqli_query($conn, "DELETE FROM alerts WHERE student_id='$student_id' AND exam_id='$exam_id'");

header("Location: result.php?exam_id=$exam_id");
exit();

?>