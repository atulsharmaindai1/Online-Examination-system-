<?php
session_start();

//  Protect page
if (!isset($_SESSION['student_id'])) {
    header("Location: Student_Login.php");
    exit();
}

include("../Teacher/conection.php");

//  FIX: removed wrong teacher_id filter
$teacher_id = $_SESSION['teacher_id'];
$exam_sql = "SELECT * FROM exams 
             WHERE teacher_id='$teacher_id' 
             ORDER BY exam_date ASC";

$exam_result = mysqli_query($conn, $exam_sql);

//  Student Results
$student_id = $_SESSION['student_id'];
$result_sql = "SELECT * FROM results WHERE student_id='$student_id'";
$result_data = mysqli_query($conn, $result_sql);

date_default_timezone_set("Asia/Kolkata");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Student Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .dashboard-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }

        .exam-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .exam-card:hover {
            transform: translateY(-5px);
        }

        .stats-card {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 10px;
        }

        .countdown {
            font-family: 'Courier New', monospace;
            font-weight: bold;
        }
    </style>
</head>

<body>

    <?php include 'nav_student.php'; ?>

    <div class="container py-5">

        <h2 class="text-white text-center mb-4">
            <i class="fas fa-tachometer-alt me-2"></i>
            Student Dashboard
        </h2>

        <!-- Quick Stats -->
        <div class="row mb-4">
            <?php
            $total_exams_taken = mysqli_num_rows($result_data);
            $avg_score = 0;
            $highest_score = 0;
            $pass_count = 0;

            if ($total_exams_taken > 0) {
                mysqli_data_seek($result_data, 0);
                $total_score = 0;
                while ($res = mysqli_fetch_assoc($result_data)) {
                    $score_percentage = ($res['score'] / $res['total_questions']) * 100;
                    $total_score += $score_percentage;
                    $highest_score = max($highest_score, $score_percentage);
                    if ($score_percentage >= 40)
                        $pass_count++;
                }
                $avg_score = round($total_score / $total_exams_taken, 1);
                mysqli_data_seek($result_data, 0);
            }
            ?>
            <div class="col-md-3 mb-3">
                <div class="stats-card p-3 text-center">
                    <i class="fas fa-clipboard-check fa-2x mb-2"></i>
                    <h4><?php echo $total_exams_taken; ?></h4>
                    <small>Exams Taken</small>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stats-card p-3 text-center">
                    <i class="fas fa-chart-line fa-2x mb-2"></i>
                    <h4><?php echo $avg_score; ?>%</h4>
                    <small>Average Score</small>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stats-card p-3 text-center">
                    <i class="fas fa-trophy fa-2x mb-2"></i>
                    <h4><?php echo $highest_score; ?>%</h4>
                    <small>Highest Score</small>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stats-card p-3 text-center">
                    <i class="fas fa-check-circle fa-2x mb-2"></i>
                    <h4><?php echo $pass_count; ?></h4>
                    <small>Passed Exams</small>
                </div>
            </div>
        </div>

        <div class="row">

            <!-- ================= EXAMS ================= -->
            <div class="col-md-8">
                <div class="dashboard-card p-4">
                    <h4 class="mb-4">
                        <i class="fas fa-calendar-alt me-2"></i>
                        Available Exams
                    </h4>

                    <?php if (mysqli_num_rows($exam_result) > 0) { ?>

                        <div class="row">

                            <?php while ($exam = mysqli_fetch_assoc($exam_result)) {

                                $duration = $exam['duration'];

                                $start = strtotime($exam['exam_date'] . " " . $exam['start_time']);
                                $end = $start + ($duration * 60);

                                // Check if student already took this exam
                                $already_taken = false;
                                $terminated = false;
                                mysqli_data_seek($result_data, 0);
                                while ($res = mysqli_fetch_assoc($result_data)) {
                                    if ($res['exam_id'] == $exam['id']) {
                                        $already_taken = true;
                                        // Check if terminated
                                        $term = mysqli_query($conn, "SELECT `terminated` FROM activity WHERE student_id='$student_id' AND exam_id='{$exam['id']}'");
                                        if ($term && mysqli_num_rows($term) > 0) {
                                            $trow = mysqli_fetch_assoc($term);
                                            if ($trow['terminated'] == 1) {
                                                $terminated = true;
                                            }
                                        }
                                        break;
                                    }
                                }
                                mysqli_data_seek($result_data, 0);
                                ?>

                                <div class="col-md-6 mb-4">
                                    <div class="exam-card h-100 p-3">
                                        <div class="card-header bg-light">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h5 class="mb-0 text-primary">
                                                    <?php echo htmlspecialchars($exam['exam_name']); ?>
                                                </h5>
                                                <?php if ($terminated) { ?>
                                                    <span class="badge bg-danger">Terminated</span>
                                                <?php } elseif ($already_taken) { ?>
                                                    <span class="badge bg-success">Completed</span>
                                                <?php } ?>
                                            </div>
                                        </div>

                                        <div class="card-body">
                                            <div class="mb-3">
                                                <p class="text-muted small mb-2">
                                                    DATE : <?php echo date("d M Y", $start); ?><br>
                                                    TIMING : <?php echo date("h:i A", $start); ?><br>
                                                    DURATION : <?php echo $duration; ?> minutes
                                                </p>
                                            </div>
                                            <!--  Countdown -->
                                            <div class="countdown text-center mb-3 p-2 bg-light rounded">
                                                <div id="countdown_<?php echo $exam['id']; ?>" class="h5 mb-1"></div>
                                                <small id="status_<?php echo $exam['id']; ?>" class="text-muted"></small>
                                            </div>


                                            <!-- Button -->
                                            <div id="btn_<?php echo $exam['id']; ?>" class="text-center">
                                                <?php if ($already_taken) { ?>
                                                    <button class="btn btn-success w-100" disabled>
                                                        <i
                                                            class="fas fa-check me-1"></i><?php echo $terminated ? 'Terminated' : 'Already Completed'; ?>
                                                    </button>
                                                <?php } else { ?>
                                                    <button class="btn btn-secondary w-100" disabled>
                                                        <i class="fas fa-clock me-1"></i>Loading...
                                                    </button>
                                                <?php } ?>
                                            </div>

                                            <!-- Hidden time -->
                                            <input type="hidden" id="start_<?php echo $exam['id']; ?>"
                                                value="<?php echo $start; ?>">
                                            <input type="hidden" id="end_<?php echo $exam['id']; ?>"
                                                value="<?php echo $end; ?>">

                                        </div>
                                    </div>
                                </div>

                            <?php } ?>

                        </div>

                    <?php } else { ?>
                        <div class="text-center py-5">
                            <i class="fas fa-calendar-times fa-4x text-muted mb-3"></i>
                            <h5 class="text-muted">No exams available</h5>
                            <p class="text-muted">Check back later for upcoming examinations</p>
                        </div>
                    <?php } ?>

                </div>
            </div>

            <!-- ================= RESULTS ================= -->
            <div class="col-md-4">
                <div class="dashboard-card p-4">
                    <h4 class="mb-4">
                        <i class="fas fa-chart-bar me-2"></i>
                        Your Results
                    </h4>

                    <?php if (mysqli_num_rows($result_data) > 0) { ?>

                        <div class="mb-3">
                            <div class="row text-center">
                                <div class="col-6">
                                    <div class="p-2 bg-light rounded">
                                        <h5 class="text-primary mb-0"><?php echo $avg_score; ?>%</h5>
                                        <small class="text-muted">Average</small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="p-2 bg-light rounded">
                                        <h5 class="text-success mb-0">
                                            <?php echo $pass_count; ?>/<?php echo $total_exams_taken; ?></h5>
                                        <small class="text-muted">Passed</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-hover table-sm">
                                <thead class="table-dark">
                                    <tr>
                                        <th>Exam</th>
                                        <th>Score</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php while ($res = mysqli_fetch_assoc($result_data)) {
                                        $percentage = $res['total_questions'] ? round(($res['score'] / $res['total_questions']) * 100, 1) : 0;
                                        $status = $percentage >= 40 ? 'PASS' : 'FAIL';
                                        $status_class = $percentage >= 40 ? 'success' : 'danger';

                                        // Get exam name
                                        $exam_name = 'Unknown exam';
                                        $exam_id = intval($res['exam_id']);
                                        $exam_query = mysqli_query($conn, "SELECT exam_name FROM exams WHERE id='$exam_id'");
                                        if ($exam_query) {
                                            $exam_row = mysqli_fetch_assoc($exam_query);
                                            if ($exam_row && isset($exam_row['exam_name'])) {
                                                $exam_name = $exam_row['exam_name'];
                                            }
                                        }
                                        ?>

                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars(substr($exam_name, 0, 20)); ?></strong>
                                                <?php if (strlen($exam_name) > 20)
                                                    echo '...'; ?>
                                            </td>
                                            <td><?php echo $percentage; ?>%</td>
                                            <td><span
                                                    class="badge bg-<?php echo $status_class; ?>"><?php echo $status; ?></span>
                                            </td>
                                        </tr>

                                    <?php } ?>

                                </tbody>
                            </table>
                        </div>

                        <div class="text-center mt-3">
                            <a href="full_results.php" class="btn btn-primary btn-sm">
                                <i class="fas fa-eye me-1"></i>View Detailed Results
                            </a>
                        </div>

                    <?php } else { ?>
                        <div class="text-center py-5">
                            <i class="fas fa-chart-bar fa-3x text-muted mb-3"></i>
                            <h6 class="text-muted">No results yet</h6>
                            <p class="text-muted small">Complete some exams to see your results here</p>
                        </div>
                    <?php } ?>

                </div>
            </div>

        </div>
    </div>

    <!-- ================= JS ================= -->
    <script>

        function updateExamStatus() {

            let now = Math.floor(Date.now() / 1000);

            document.querySelectorAll("[id^='start_']").forEach(function (el) {

                let id = el.id.split("_")[1];

                let start = parseInt(document.getElementById("start_" + id).value);
                let end = parseInt(document.getElementById("end_" + id).value);

                let statusEl = document.getElementById("status_" + id);
                let btnEl = document.getElementById("btn_" + id);
                let countdownEl = document.getElementById("countdown_" + id);

                if (now < start) {

                    statusEl.innerHTML = "Not Started";
                    statusEl.className = "text-warning";

                    let diff = start - now;
                    if (diff < 3600) {
                        countdownEl.innerHTML = "Starts in: " + formatTime(diff);
                    }

                    btnEl.innerHTML = "<button class='btn btn-secondary btn-sm' disabled>Not Available</button>";

                }
                else if (now >= start && now <= end) {

                    statusEl.innerHTML = "Active";
                    statusEl.className = "text-success";

                    let diff = end - now;
                    countdownEl.innerHTML = "Ends in: " + formatTime(diff);

                    btnEl.innerHTML = "<a href='exam.php?exam_id=" + id + "' class='btn btn-primary btn-sm'>Join Exam</a>";

                }
                else {

                    statusEl.innerHTML = "Finished";
                    statusEl.className = "text-danger";

                    countdownEl.innerHTML = "Exam Ended";

                    btnEl.innerHTML = "<button class='btn btn-danger btn-sm' disabled>Finished</button>";
                }

            });
        }

        //  Time format
        function formatTime(sec) {
            let h = Math.floor(sec / 3600);
            let m = Math.floor((sec % 3600) / 60);
            let s = sec % 60;
            return h + "h " + m + "m " + s + "s";
        }

        //  Run every second
        setInterval(updateExamStatus, 1000);
        updateExamStatus();

    </script>

    <?php include '../footer.html'; ?>
</body>

</html>