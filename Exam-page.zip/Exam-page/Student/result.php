<?php
session_start();

if (!isset($_SESSION['student_id'])) {
    header("Location: Student_Login.php");
    exit();
}

include("../Teacher/conection.php");

$exam_id = intval($_GET['exam_id'] ?? 0);
$student_id = $_SESSION['student_id'];

if (!$exam_id) {
    echo '<div class="container py-5"><div class="alert alert-danger">Invalid exam ID.</div></div>';
    exit();
}

// Get result
$result_query = mysqli_query($conn, "SELECT * FROM results WHERE student_id='$student_id' AND exam_id='$exam_id'");
if (!$result_query) {
    echo '<div class="container py-5"><div class="alert alert-danger">Database error: ' . mysqli_error($conn) . '</div></div>';
    exit();
}

$result = mysqli_fetch_assoc($result_query);
if (!$result) {
    echo '<div class="container py-5"><div class="alert alert-warning">No result found for this exam.</div></div>';
    exit();
}



$percentage = $result['total_questions'] > 0 ? round(($result['score'] / $result['total_questions']) * 100, 2) : 0;
$status = $percentage >= 40 ? "PASS" : "FAIL";
$status_class = $percentage >= 40 ? "success" : "danger";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Result</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .result-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            backdrop-filter: blur(10px);
        }
        .score-circle {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            font-weight: bold;
            margin: 0 auto;
            position: relative;
        }
        .score-circle::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: conic-gradient(
                <?php echo $percentage >= 40 ? '#28a745' : '#dc3545'; ?> 0% <?php echo $percentage; ?>%,
                #e9ecef <?php echo $percentage; ?>% 100%
            );
            mask: radial-gradient(circle at center, transparent 60%, black 60%);
            -webkit-mask: radial-gradient(circle at center, transparent 60%, black 60%);
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-dark bg-dark px-4">
    <span class="navbar-brand fw-bold">Online Examination System</span>
    <div class="text-white">
        Welcome, <?php echo htmlspecialchars($_SESSION['student_name'] ?? 'Student'); ?> |
        <a href="logout.php" class="btn btn-danger btn-sm ms-2">Logout</a>
    </div>
</nav>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="result-card p-5">

                <!-- Header -->
                <div class="text-center mb-4">
                    <h2 class="mb-3"><i class="bi bi-clipboard-data"> </i>Exam Result</h2>
                    <h4 class="text-primary"><?php echo htmlspecialchars($result['Exam_Name']); ?></h4>
                </div>

                <!-- Score Circle -->
                <div class="mb-4">
                    <div class="score-circle text-<?php echo $status_class; ?>">
                        <?php echo $percentage; ?>%
                    </div>
                </div>

                <!-- Status -->
                <div class="text-center mb-4">
                    <h3 class="text-<?php echo $status_class; ?>">
                        <i class="fas fa-<?php echo $percentage >= 40 ? 'check-circle' : 'times-circle'; ?> me-2"></i>
                        <?php echo $status; ?>
                    </h3>
                </div>

                <!-- Details -->
                <div class="row text-center mb-4">
                    <div class="col-md-4">
                        <div class="p-3 bg-light rounded">
                            <h5 class="text-primary"><?php echo $result['score']; ?></h5>
                            <small class="text-muted">Correct Answers</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="p-3 bg-light rounded">
                            <h5 class="text-danger"><?php echo $result['total_questions'] - $result['score']; ?></h5>
                            <small class="text-muted">Wrong Answers</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="p-3 bg-light rounded">
                            <h5 class="text-info"><?php echo $result['total_questions']; ?></h5>
                            <small class="text-muted">Total Questions</small>
                        </div>
                    </div>
                </div>

                <!-- Performance Message -->
                <div class="alert alert-<?php echo $status_class; ?> text-center mb-4">
                    <?php if($percentage >= 90): ?>
                        <strong>Excellent!</strong> Outstanding performance! 🎉
                    <?php elseif($percentage >= 75): ?>
                        <strong>Great Job!</strong> Very good performance! 👍
                    <?php elseif($percentage >= 60): ?>
                        <strong>Good Work!</strong> Satisfactory performance! 👏
                    <?php elseif($percentage >= 40): ?>
                        <strong>Passed!</strong> You made it! Keep improving! 💪
                    <?php else: ?>
                        <strong>Need Improvement!</strong> Don't give up, try harder next time! 📚
                    <?php endif; ?>
                </div>

                <!-- Actions -->
                <div class="text-center">
                    <a href="student_dashboard.php" class="btn btn-primary">
                        <i class="fas fa-home me-1"></i> Back to Dashboard
                    </a>
                </div>

            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <?php include '../footer.html'; ?>
</body>
</html>