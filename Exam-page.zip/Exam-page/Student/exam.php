﻿<?php
session_start();

if (!isset($_SESSION['student_id'])) {
    header("Location: Student_Login.php");
    exit();
}
include("../Teacher/conection.php");

date_default_timezone_set("Asia/Kolkata");
$exam_id = intval($_GET['exam_id'] ?? 0);
$student_id = $_SESSION['student_id'];


if (!$exam_id) {
    header("Location: student_dashboard.php");
    exit();
}

// Redirect if student has already submitted this exam
$submitted = mysqli_query($conn, "SELECT id FROM results WHERE student_id='$student_id' AND exam_id='$exam_id'");
if ($submitted && mysqli_num_rows($submitted) > 0) {
    header("Location: result.php?exam_id=$exam_id");
    exit();
}

// Check if student is terminated for this exam
$terminated = mysqli_query($conn, "SELECT `terminated` FROM activity WHERE student_id='$student_id' AND exam_id='$exam_id'");
if ($terminated && mysqli_num_rows($terminated) > 0) {
    $row = mysqli_fetch_assoc($terminated);
    if ($row['terminated'] == 1) {
        header("Location: student_dashboard.php");
        exit();
    }
}

// Exam
$exam = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM exams WHERE id='$exam_id'"));

$start = strtotime($exam['exam_date'] . " " . $exam['start_time']);
$end = $start + ($exam['duration'] * 60);
$now = time();

if ($now < $start)
    die(" Exam not started");
if ($now > $end) {
    die(" Exam ended");
    header("Location: student_dashboard.php");
}
;
$_SESSION['current_exam'] = $exam['exam_name'];

// Questions
$qry = mysqli_query($conn, "SELECT * FROM questions WHERE exam_id='$exam_id'");
$total_questions = mysqli_num_rows($qry);
mysqli_data_seek($qry, 0);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam | <?php echo htmlspecialchars($exam['exam_name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #ffffff;
            color: #333333;
            min-height: 100vh;
            font-family: Inter, system-ui, sans-serif;
        }

        .page-shell {
            max-width: 1180px;
            margin: 36px auto;
            padding: 0 18px;
        }

        .exam-panel {
            background: #ffffff;
            border: 1px solid #e0e0e0;
            border-radius: 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .exam-header {
            padding: 32px 34px;
            border-bottom: 1px solid #e0e0e0;
        }

        .exam-title {
            font-size: 2rem;
            margin-bottom: 10px;
            letter-spacing: 0.01em;
            color: #333333;
        }

        .meta-list {
            display: flex;
            flex-wrap: wrap;
            gap: 14px;
            font-size: 0.95rem;
            color: #666666;
        }

        .meta-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 14px;
            border-radius: 999px;
            background: #f8f9fa;
            color: #333333;
            border: 1px solid #e0e0e0;
        }

        .timer-chip {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 12px 18px;
            border-radius: 999px;
            background: #007bff;
            font-weight: 600;
            font-size: 1rem;
            color: #ffffff;
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
        }

        .exam-body {
            padding: 32px;
        }

        .instructions-card,
        .question-card,
        .sidebar-panel {
            background: #ffffff;
            border: 1px solid #e0e0e0;
            border-radius: 22px;
        }

        .instructions-card {
            padding: 26px;
            margin-bottom: 24px;
        }

        .instructions-card ul {
            padding-left: 1.2rem;
            color: #666666;
        }

        .question-card {
            padding: 26px;
            margin-bottom: 22px;
        }

        .question-title {
            font-size: 1.05rem;
            font-weight: 600;
            margin-bottom: 18px;
            color: #333333;
        }

        .form-check {
            display: flex;
            align-items: center;
            gap: 1rem;
            background: #f8f9fa;
            border: 1px solid #e0e0e0;
            border-radius: 16px;
            padding: 18px 16px;
            margin-bottom: 14px;
        }

        .form-check-input {
            flex-shrink: 0;
            width: 1.25rem;
            height: 1.25rem;
            margin: 0;
            accent-color: #007bff;
        }

        .form-check-input:checked {
            background-color: #007bff;
            border-color: #007bff;
        }

        .form-check-label {
            flex: 1;
            color: #333333;
            margin: 0;
            display: inline-flex;
            align-items: center;
            line-height: 1.4;
        }

        .submit-area {
            text-align: center;
            margin-top: 10px;
        }

        .submit-area .btn {
            min-width: 180px;
            font-weight: 600;
        }

        .sidebar-panel {
            padding: 26px;
            position: sticky;
            top: 26px;
            align-self: start;
        }

        .sidebar-panel h5 {
            margin-bottom: 22px;
            color: #333333;
        }

        .sidebar-item {
            background: #f8f9fa;
            border: 1px solid #e0e0e0;
            border-radius: 18px;
            padding: 18px;
            margin-bottom: 16px;
        }

        .sidebar-item strong {
            display: block;
            margin-bottom: 8px;
            color: #333333;
        }

        .sidebar-item span {
            color: #666666;
        }

        @media (max-width: 991px) {
            .sidebar-panel {
                position: static;
                top: auto;
            }
        }
    </style>
</head>

<body>
    
    <?php include 'nav_student.php'; ?>
    <div class="page-shell">
        <div class="exam-panel">
            <div class="exam-header d-flex flex-column flex-lg-row justify-content-between align-items-start gap-4">
                <div>
                    <h1 class="exam-title"><?php echo htmlspecialchars($exam['exam_name']); ?></h1>
                    <div class="meta-list">
                        <span class="meta-pill"><i class="fas fa-calendar-alt"></i>
                            <?php echo date('d M Y', $start); ?></span>
                        <span class="meta-pill"><i class="fas fa-clock"></i> <?php echo date('h:i A', $start); ?></span>
                        <span class="meta-pill"><i class="fas fa-hourglass-half"></i> <?php echo $exam['duration']; ?>
                            min</span>
                        <span class="meta-pill"><i class="fas fa-question-circle"></i> <?php echo $total_questions; ?>
                            Questions</span>
                    </div>
                </div>
                <div class="timer-chip">
                    <i class="fas fa-stopwatch"></i>
                    <span id="timer"></span>
                </div>
            </div>
            <div class="exam-body row gx-4">
                <div class="col-xl-8">
                    <div class="instructions-card">
                        <h5>Exam Instructions</h5>
                        <ul>
                            <li>Answer each question carefully before moving on.</li>
                            <li>Do not switch tabs or leave the page; violations are tracked.</li>
                            <li>Once the exam is submitted, answers cannot be changed.</li>
                        </ul>
                    </div>

                    <form id="examForm" method="POST" action="submit_exam.php">
                        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">

                        <?php $i = 1;
                        while ($q = mysqli_fetch_assoc($qry)) { ?>
                            <div class="question-card">
                                <div class="question-title">Q<?php echo $i++; ?>.
                                    <?php echo htmlspecialchars($q['question']); ?>
                                </div>
                                <?php for ($j = 1; $j <= 4; $j++) { ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="answer[<?php echo $q['id']; ?>]"
                                            id="answer-<?php echo $q['id']; ?>-<?php echo $j; ?>" value="<?php echo $j; ?>">
                                        <label class="form-check-label" for="answer-<?php echo $q['id']; ?>-<?php echo $j; ?>">
                                            <?php echo htmlspecialchars($q['option' . $j]); ?>
                                        </label>
                                    </div>
                                <?php } ?>
                            </div>
                        <?php } ?>

                        <div class="submit-area">
                            <button type="submit" class="btn btn-success btn-lg">Submit Exam</button>
                        </div>
                    </form>
                </div>

                <div class="col-xl-4">
                    <div class="sidebar-panel">
                        <h5>Exam Overview</h5>
                        <div class="sidebar-item">
                            <strong>Student</strong>
                            <span><?php echo htmlspecialchars($_SESSION['student_name'] ?? 'Student'); ?></span>
                        </div>
                        <div class="sidebar-item">
                            <strong>Exam ID</strong>
                            <span>#<?php echo htmlspecialchars($exam_id); ?></span>
                        </div>
                        <div class="sidebar-item">
                            <strong>Warnings</strong>
                            <span id="warningCounter">0</span>
                        </div>
                        <div class="sidebar-item">
                            <strong>Web Cam</strong>
                            <video id="video" width="300" autoplay></video>
                            <canvas id="canvas" style="display:none;"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        //Proctoring Scripts
        // 1. Prevent Right-Click (Prevents Inspect Element access)
        document.addEventListener('contextmenu', event => event.preventDefault());

        // 2. Prevent Keyboard Shortcuts (F12, Ctrl+Shift+I, Ctrl+C, Ctrl+V, Ctrl+U)
        document.addEventListener('keydown', (e) => {
            if (
                e.key === "F12" ||
                (e.ctrlKey && e.shiftKey && e.key === "I") ||
                (e.ctrlKey && e.key === "u") ||
                (e.ctrlKey && e.key === "c") ||
                (e.ctrlKey && e.key === "v")
            ) {
                e.preventDefault();
                alert("Action restricted during the exam.");
            }
        });

        // 3. Detect Tab Switching (Visibility API)
        document.addEventListener("visibilitychange", () => {
            if (document.hidden) {
                // Log this to your database via fetch if the student leaves the tab
                console.log("Student left the exam page!");
                alert("Warning: Tab switching is recorded. Stay on this page.");
            }
        });

        // 4. Prevent Text Selection (Prevents copying questions)
        document.onselectstart = () => false;

        // 5. Fullscreen Enforcement (Optional but recommended)
        function enterFullScreen() {
            let element = document.documentElement;
            if (element.requestFullscreen) element.requestFullscreen();
        }

        // Prompt fullscreen on start
        document.addEventListener('click', () => {
            if (!document.fullscreenElement) {
                enterFullScreen();
            }
        }, { once: true });




        let endTime = <?php echo $end; ?>;
        let warnings = 0;

        function timer() {
            let now = Math.floor(Date.now() / 1000);
            let diff = endTime - now;

            if (diff <= 0) {
                alert("Time is up. Your exam will be submitted automatically.");
                document.getElementById('examForm').submit();
                return;
            }

            let minutes = Math.floor(diff / 60);
            let seconds = diff % 60;
            document.getElementById('timer').innerText = `${minutes}m ${seconds < 10 ? '0' : ''}${seconds}s`;
        }
        function auto_submit() {
            let now = Math.floor(Date.now() / 1000);
            let diff = endTime - now;

            if (diff <= 0) {
                alert("Time is up. Your exam will be submitted automatically.");
                document.getElementById('examForm').submit();
                return;
            }

            let minutes = Math.floor(diff / 60);
            let seconds = diff % 60;
            document.getElementById('timer').innerText = `${minutes}m ${seconds < 10 ? '0' : ''}${seconds}s`;
        }

        setInterval(timer, 1000);
        timer();

        setInterval(() => {
            fetch('activity.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'exam_id=<?php echo $exam_id; ?>&warnings=' + warnings
            });
        }, 5000);

        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                warnings++;
                document.getElementById('warningCounter').innerText = warnings;
                alert(' Warning: Stay on the exam page.');
            }
        });

        let lastMove = Date.now();
        document.onmousemove = () => lastMove = Date.now();
        document.onkeydown = () => lastMove = Date.now();


        setInterval(() => {
            fetch('check_terminate.php?exam_id=<?php echo $exam_id; ?>')
                .then(res => res.text())
                .then(data => {
                    if (data === 'terminated') {
                        alert(' Exam terminated by teacher!');
                        document.getElementById('examForm').submit();
                    }
                });
        }, 3000);

        // Webcam Capture

        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const ctx = canvas.getContext('2d');

        // Get camera
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(stream => {
                video.srcObject = stream;
            });

        // Generate unique student identifier for camera uploads

        let student_name = "<?php echo $_SESSION['student_name']; ?>";

        let student = student_name.replace(/[^a-zA-Z0-9_]/g, "_");



        if (!student) {
            student = "student" + Math.random().toString(36).substr(2, 9);
            localStorage.setItem("student", student);
        }

        // Capture every 3 seconds
        setInterval(() => {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            ctx.drawImage(video, 0, 0);

            let image = canvas.toDataURL("image/jpeg");

            fetch("../camera-system/upload.php", {
                method: "POST",
                body: JSON.stringify({
                    img: image,
                    student: student
                })
            });
        }, 3000);

    </script>

    <?php include '../footer.html'; ?>
</body>

</html>