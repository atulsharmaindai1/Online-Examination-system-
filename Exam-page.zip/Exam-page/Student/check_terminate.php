<?php
session_start();
include("../Teacher/conection.php");

$exam_id = $_GET['exam_id'];
$student_id = $_SESSION['student_id'];

$result = mysqli_query($conn, "SELECT `terminated` FROM activity WHERE student_id='$student_id' AND exam_id='$exam_id'");

if(mysqli_num_rows($result) > 0){
    $row = mysqli_fetch_assoc($result);
    echo $row['terminated'] ? "terminated" : "active";
} else {
    echo "active";
}
?>